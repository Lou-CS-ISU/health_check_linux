UPDATE [dbo].[Trans]
SET    [IsTradeFromTdyFlg] = 0
WHERE   1<>1;
