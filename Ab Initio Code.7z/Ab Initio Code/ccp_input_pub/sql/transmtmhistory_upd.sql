UPDATE [dbo].[TransMTMHistory]
   SET 
      [MtmAmt] = :MtmAmt
      ,[MrkInCrncyAmt] = :MrkInCrncyAmt
      ,[MrkCalcDt] = :MrkCalcDt
      ,[MrkCrncyId] = :MrkCrncyId
      ,[AplyDt] = :AplyDt
      ,[SrcId] = :SrcId
      ,[UpdtUserNm] = :UpdtUserNm
      ,[UserMchnAddr] = :UserMchnAddr
      ,[UpdtTs] = :UpdtTs
 WHERE TransactionMTMHistId = :TransactionMTMHistId
