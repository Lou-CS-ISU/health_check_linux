SELECT * FROM dbo.AssetAll WHERE SrcId IN (SELECT SrcId FROM dbo.SrcSys WHERE SrcSysNm='SCW' and SrcFileTagNm='SIMCORPWEST_ASSET');
