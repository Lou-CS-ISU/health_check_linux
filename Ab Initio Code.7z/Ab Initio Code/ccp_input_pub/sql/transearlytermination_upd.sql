UPDATE [dbo].[TransEarlyTermination]
   SET
 ErlyTermnDt            = :ErlyTermnDt
,ErlyTermnTypId           = :ErlyTermnTypId
,SrcId             	    = :SrcId
,UpdtUserNm             = :UpdtUserNm
,UserMchnAddr           = :UserMchnAddr
,UpdtTs                 = :UpdtTs
 WHERE
       TransactionErlyTermnId = :TransactionErlyTermnId
