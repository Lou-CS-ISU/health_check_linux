UPDATE [dbo].[TransEquityBasketComponent]
SET
TransactionEqtyPrntId = :TransactionEqtyPrntId,
TransactionEqtyOptnPrntId = :TransactionEqtyOptnPrntId,
AssetId = :AssetId,
BasketNm = :BasketNm,
CmponNm = :CmponNm,
CmponShares = :CmponShares,
CmponWt = :CmponWt,
CmponPrice = :CmponPrice,
CmponIndst = :CmponIndst,
CmponSctr = :CmponSctr,
CUSIP = :CUSIP,
ISIN = :ISIN,
RowNbr = :RowNbr,
EQDRuleOvrdCashDvdndKey = :EQDRuleOvrdCashDvdndKey,
CoRSAssetCd = :CoRSAssetCd,
LkpSrcAssetCd = :LkpSrcAssetCd,
SrcTransactionId = :SrcTransactionId,
BsnsDt = :BsnsDt,
UserMchnAddr = :UserMchnAddr,
UpdtUserNm = :UpdtUserNm,
UpdtTs = :UpdtTs
WHERE
TransEqtyBasketCmponId = :TransEqtyBasketCmponId
