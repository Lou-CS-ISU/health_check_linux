    SELECT custfac.[CustomerFacilityGrdId]
,custbase.[CoRSCustomerId]
,org.[OrgEntyIdNm]
--,custfac.[ProductTypId]
,case when prod.productid is not null then prod.productnm
    when class.productclassid is not null then class.productclassnm
    when subclass.productsubclassid is not null then subclass.productsubclassnm
   when grp.productgrpid is not null then grp.productgrpnm
   end ProdTypNm
,GCBQR.[Gnrcclassval] BQRID
,custfac.[DtOfAprvl]
,GCCQR.[Gnrcclassval] CQRID
,custfac.[AQRId] AQRID
 FROM [CoRSINPUT].[dbo].[CustomerFacilityGrade] custfac
 left outer join [CoRSINPUT].[dbo].[CustomerBase] custbase on custfac.[CustomerId] = custbase.[CustomerId]
 left outer join [CoRSINPUT].[dbo].[Organization] org on custfac.[WLEId] = org.OrgId
 left outer join [CoRSINPUT].[dbo].[Product] prod on prod.[productid] = custfac.[ProductTypId]
left outer join [CoRSINPUT].[dbo].[ProductClass] class on class.[ProductClassId] = custfac.[ProductTypId]
left outer join [CoRSINPUT].[dbo].[ProductSubclass] subclass on subclass.[ProductSubclassId] = custfac.[ProductTypId]
left outer join [CoRSINPUT].[dbo].[ProductGroup] grp on grp.[productgrpid] = custfac.[ProductTypId]
LEFT OUTER JOIN [CoRSINPUT].[dbo].[Gnrcclass] GCBQR on custfac.BQRID = GCBQR.GnrcclassId
LEFT OUTER JOIN [CoRSINPUT].[dbo].[Gnrcclass] GCCQR on custfac.[CQRId] = GCCQR.[GnrcclassId]

