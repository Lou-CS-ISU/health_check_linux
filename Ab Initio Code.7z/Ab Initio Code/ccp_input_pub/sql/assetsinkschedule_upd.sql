UPDATE dbo.AssetSinkSchedule SET
	[AssetId] = :AssetId
	,[SinkDt] = :SinkDt
	,[SinkPrice] = :SinkPrice
	,[SinkAmt] = :SinkAmt
	,[AdtnlSinkAmt] = :AdtnlSinkAmt
	,[SrcId] = :SrcId
	,[UpdtUserNm] = :UpdtUserNm
	,[UpdtTs] = :UpdtTs
WHERE AssetSinkSchedId = :AssetSinkSchedId
