UPDATE dbo.TransLoanMoneyMarket SET
        IncldIndFlg                           = :IncldIndFlg,
        ExpsrValInCrncyAmt                    = :ExpsrValInCrncyAmt,
        ExpsrValInUSDAmt                        = :ExpsrValInUSDAmt,
        NetActvyAmt                           = :NetActvyAmt,
		BookActvyAmt                          = :BookActvyAmt,
		NetBookBalAmt                         = :NetBookBalAmt,
        NewExstgInd                           = :NewExstgInd,
        UserMchnAddr                    = :UserMchnAddr,
        UpdtUserNm                      = :UpdtUserNm,
        UpdtTs                          = :UpdtTs
WHERE TransactionId = :TransactionId
