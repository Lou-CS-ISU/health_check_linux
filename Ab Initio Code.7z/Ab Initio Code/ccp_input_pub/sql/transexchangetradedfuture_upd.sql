UPDATE dbo.TransExchangeTradedFuture
SET EqtySharesCount   = :EqtySharesCount
,IndxTenorCd		  = :IndxTenorCd
,ParNotionalAmt	  = :ParNotionalAmt
,PayIndxNm		  = :PayIndxNm
,PayIndxTenorNm	  = :PayIndxTenorNm
,PayRcvInd		  = :PayRcvInd
,PayFreqNm		  = :PayFreqNm
,RcvIndxNm		  = :RcvIndxNm
,RcvIndxTenorNm	  = :RcvIndxTenorNm
,RcvFreqNm		  = :RcvFreqNm
,UndlySecCd		  = :UndlySecCd
,UndlySpotPrice	  = :UndlySpotPrice
,InitialPrice	  = :InitialPrice
,UserMchnAddr	  = :UserMchnAddr
,UpdtUserNm		  = :UpdtUserNm
,UpdtTs			  = :UpdtTs
WHERE TransactionId = :TransactionId
