update dbo.Asset 
set 
UpdtTs				=:UpdtTs,
UpdtUserNm			=:UpdtUserNm
where 
AssetId			=:AssetId
