UPDATE [dbo].[TransEquityPFECashDvdndSched]
SET
TransactionId=:TransactionId,
LegExDate=:LegExDate,
DividendPayDate=:DividendPayDate,
Shares=:Shares,
ExchangeRate=:ExchangeRate,
DividendMultiplier=:DividendMultiplier,
CumulativeDividend=:CumulativeDividend,
EquitySymbol=:EquitySymbol,
HoldingIdentifier=:HoldingIdentifier,
EQDRuleOverrideCashDividendKey=:EQDRuleOverrideCashDividendKey
WHERE 
TransEqtyCashDvdndSchedId=:TransEqtyCashDvdndSchedId
