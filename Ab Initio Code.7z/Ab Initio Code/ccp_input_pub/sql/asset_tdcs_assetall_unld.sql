SELECT * FROM dbo.AssetAll WHERE SrcId IN (SELECT SrcId FROM dbo.SrcSys WHERE SrcSysNm='TDCS' and SrcFileTagNm='WHM_ASSET');
