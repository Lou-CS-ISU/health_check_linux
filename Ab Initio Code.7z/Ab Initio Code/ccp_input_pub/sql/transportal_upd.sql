UPDATE dbo.TransPortal
  SET TradeAprvlAmt=:TradeAprvlAmt,
  MrkOvrdAmt=:MrkOvrdAmt,
  MrkOvrdExpiryDt=:MrkOvrdExpiryDt,
  MrkOvrdFlg=:MrkOvrdFlg,
  Comments=:Comments,
  MrkOvrdinCrncyAmt=:MrkOvrdinCrncyAmt,
  MrkOvrdCrncyId=:MrkOvrdCrncyId,
  PortalStatId=:PortalStatId,
  TradeRvrslDt=:TradeRvrslDt,
  SrcId=:SrcId,
  CrteUserNm=:CrteUserNm,
  CrteTs=:CrteTs,
  UserMchnAddr=:UserMchnAddr,
  UpdtUserNm=:UpdtUserNm,
  UpdtTs=:UpdtTs
 WHERE TransactionId =:TransactionId

