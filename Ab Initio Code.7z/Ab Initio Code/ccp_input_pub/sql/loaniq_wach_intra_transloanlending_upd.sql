UPDATE dbo.TransLoanLending SET
         NewExstgInd                           = :NewExstgInd,
	ExpsrinCrncyAmt    		       = :ExpsrinCrncyAmt,
	ExpsrinUSDAmt                          = :ExpsrinUSDAmt,
	PrnclBalCurrAmt                        = :PrnclBalCurrAmt,
	OstndInUSDAmt                          = :OstndInUSDAmt,
 	OstndInCrncyAmt                        = :OstndInCrncyAmt,
	UserMchnAddr                    = :UserMchnAddr,
        UpdtUserNm                      = :UpdtUserNm,
        UpdtTs                          = :UpdtTs
WHERE TransactionId = :TransactionId
