UPDATE CustomerHierarchy
      SET 
          PrntCustomerId = :PrntCustomerId,
          RiskOwnrshpPct = :RiskOwnrshpPct,
          RltnpTypNm = :RltnpTypNm,
          SrcId = :SrcId,
          UpdtUserNm = :UpdtUserNm,
          UserMchnAddr = :UserMchnAddr,
          UpdtTs = :UpdtTs,
          DBPrntClntNbr = :DBPrntClntNbr,
          CustomerHierarchyTypId = :CustomerHierarchyTypId
      WHERE
            CustomerId = :CustomerId 
            and SrcId = :SrcId
         
