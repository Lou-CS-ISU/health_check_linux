SELECT  [LimitId] as PrtflioLimitId
     -- ,[PrtflioCubeId]
          ,g1.[GnrcClassVal] as [PrtflioGrpId]
     -- ,l.[CustomerId]
          ,c1.[CoRSCustomerId] as [CptyId]
		   -- ,[CptyId]
          ,c2.[CoRSCustomerId] as TrdngCptyId
     ---   ,l.[WLEntyId]
          ,o.[OrgEntyIdNm] as [WfOrgId]
    ---      ,l.[ProductIDNew]
          ,p.ProductNm as ProductId
		     --- ,l.[CntryCdId]
          ,cw.[CntryNm] as LocId
    --  ,p.[ProductHierarchyTypNm]
    --  ,l.[RiskMeasureLkpId] 
          ,r.[RiskMsrLkpShortNm] as [RiskMsrDfntnId]
      ,[LimitPntNm]
      ,[ExprDt]
      ,[TenorVal]
   --   ,[LimitCrncyId]
          ,cu.[CrncyISOCd] as [CrncyId]
  --    ,[LimitStatId1] as [LimitStatId] 
          ,g2.[GnrcClassVal] as LimitStatId
      ,[LimitActvFlg] as LimitActvInd
      ,[Notes]

  FROM (
SELECT [LimitId]
      ,[PrtflioCubeId]
          ,[CustomerId]
          ,[CntryCdId]
          ,WLEId as [WLEntyId]
          ,[CptyId]
          ,coalesce([ProductId],[ProductGrpId],[ProductClassId],[ProductSubClassId]) as ProductIdNew
          ,RiskMsrLkpId as [RiskMeasureLkpId]
          ,[LimitPntNm]
      ,[ExprDt]
          ,'NA' AS TenorVal
      ,[LimitCrncyId]
          ,[LimitStatId] as [LimitStatId1]
          ,[LimitActvFlg]
      ,[Notes]
          FROM  [CoRSINPUT].[dbo].[Limit]
      ) l
  LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g1
   ON l.[PrtflioCubeId] = g1.[GnrcClassId]
        LEFT JOIN  [CoRSINPUT].[dbo].[CustomerBase] c1
        ON l.[CustomerId] = c1.[CustomerId]
        LEFT JOIN [CoRSINPUT].[dbo].[MasterCountryCodes] cw
        ON l.[CntryCdId] = cw.[CntryCdId]
        LEFT JOIN [CoRSINPUT].[dbo].[Organization] o
        ON l.[WLEntyId] = o.[OrgId]
        LEFT JOIN  [CoRSINPUT].[dbo].[CustomerBase] c2
        ON l.[CptyId] = c2.[CustomerId]
        LEFT JOIN (SELECT [ProductId] As ProductID
      ,[ProductNm] As ProductNm
      ,[ProductHierarchyTypNm]
      FROM [CoRSINPUT].[dbo].[Product]
UNION
SELECT [ProductClassId] As ProductID
      ,[ProductClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
        FROM [CoRSINPUT].[dbo].[ProductClass]
UNION
SELECT [ProductGrpId] As ProductID
      ,[ProductGrpNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductGroup]
UNION
SELECT [ProductSubClassId] As ProductID
      ,[ProductSubClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductSubclass]) p
  ON l.ProductIdNew= p.ProductID
LEFT JOIN [CoRSINPUT].[dbo].[RiskMeasureLKP] r
ON l.[RiskMeasureLkpId] = r.[RiskMsrLkpId]
LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu
ON l.LimitCrncyId = cu.[CrncyId]
LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g2
   ON l.[LimitStatId1] = g2.[GnrcClassId]
;
