SELECT  [LimitId]
      ,[PrtflioCubeId]
          ,g1.[GnrcClassVal] as PrtflioCubeNm
      ,l.[CustomerId]
          ,c1.[CustomerShortNm] as CptyNm
      ,l.[CntryCdId]
          ,cw.[CntryNm]
      ,l.[WLEntyId]
          ,o.[OrgEntyIdNm]
      ,[CptyId]
          ,c2.[CustomerShortNm] as TrdngCptyNm
      ,l.[ProductID]
          ,p.ProductNm
      ,p.[ProductHierarchyTypNm]
      ,l.[RiskMeasureLkpId]
          ,r.[RiskMsrLkpShortNm]
      ,[LimitPntNm]
      ,[ExprDt]
      ,[TenorVal]
      ,[LimitCrncyId]
          ,cu.[CrncyISOCd]
      ,[LimitStatId]
          ,g2.[GnrcClassVal] as LimitStNm
      ,[LimitActvFlg]
      ,[Notes]

  FROM (
SELECT [LimitId]
      ,[PrtflioCubeId]
          ,[CustomerId]
          ,[CntryCdId]
          ,WLEId as [WLEntyId]
          ,[CptyId]
          ,coalesce([ProductId],[ProductGrpId],[ProductClassId],[ProductSubClassId]) as ProductId
          ,RiskMsrLkpId as [RiskMeasureLkpId]
          ,[LimitPntNm]
      ,[ExprDt]
          ,'NA' AS TenorVal
      ,[LimitCrncyId]
          ,[LimitStatId]
          ,[LimitActvFlg]
      ,[Notes]
          FROM  [CoRSINPUT].[dbo].[Limit]
      ) l
  LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g1
   ON l.[PrtflioCubeId] = g1.[GnrcClassId]
        LEFT JOIN  [CoRSINPUT].[dbo].[Customer] c1
        ON l.[CustomerId] = c1.[CustomerId]
        LEFT JOIN [CoRSINPUT].[dbo].[MasterCountryCodes] cw
        ON l.[CntryCdId] = cw.[CntryCdId]
        LEFT JOIN [CoRSINPUT].[dbo].[Organization] o
        ON l.[WLEntyId] = o.[OrgId]
        LEFT JOIN  [CoRSINPUT].[dbo].[Customer] c2
        ON l.[CptyId] = c2.[CustomerId]
        LEFT JOIN (SELECT [ProductId] As ProductID
      ,[ProductNm] As ProductNm
      ,[ProductHierarchyTypNm]
      FROM [CoRSINPUT].[dbo].[Product]
UNION
SELECT [ProductClassId] As ProductID
      ,[ProductClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
        FROM [CoRSINPUT].[dbo].[ProductClass]
UNION
SELECT [ProductGrpId] As ProductID
      ,[ProductGrpNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductGroup]
UNION
SELECT [ProductSubClassId] As ProductID
      ,[ProductSubClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductSubclass]) p
  ON l.[ProductId]= p.ProductID
LEFT JOIN [CoRSINPUT].[dbo].[RiskMeasureLKP] r
ON l.[RiskMeasureLkpId] = r.[RiskMsrLkpId]
LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu
ON l.LimitCrncyId = cu.[CrncyId]
LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g2
   ON l.[LimitStatId] = g2.[GnrcClassId]
;
