UPDATE [dbo].[TransLoanRiskCustomer]
   SET [CustomerNm]     = :CustomerNm
      ,[RiskMtgntPct]   = :RiskMtgntPct
      ,[MtgntTyp]       = :MtgntTyp
      ,[StatCd]         = :StatCd
      ,[UserMchnAddr]   = :UserMchnAddr
      ,[UpdtUserNm]     = :UpdtUserNm
      ,[UpdtTs]         = :UpdtTs
 WHERE TransactionId    = :TransactionId AND
       CustomerId       = :CustomerId
