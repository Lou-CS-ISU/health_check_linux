update dbo.Trans 
set 
IsTradeFromTdyFlg =1, 
CDCUpdtDt =GETDATE()
where 
TransactionId =:TransactionId
