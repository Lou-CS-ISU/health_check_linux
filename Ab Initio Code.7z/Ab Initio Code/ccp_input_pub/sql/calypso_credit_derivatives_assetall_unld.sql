select * from AssetAll A, SrcSys S where A.SrcId= S.SrcId and ((S.SrcSysNm='ProductDetail' and S.SrctypCd = 'F') or (S.SrcSysNm in ('Portal','Manual')))
