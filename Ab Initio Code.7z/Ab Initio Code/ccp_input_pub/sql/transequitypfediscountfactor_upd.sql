UPDATE [dbo].[TransEquityPFEDiscountFactor]
SET
BusinessDate = :BusinessDate,
Id = :Id,
Dt = :Dt,
Val = :Val,
UserMchnAddr = :UserMchnAddr,
UpdtUserNm = :UpdtUserNm,
UpdtTs = :UpdtTs
WHERE
TransEqtyDscntFactorId = :TransEqtyDscntFactorId
