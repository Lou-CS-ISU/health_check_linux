select * from (SELECT * FROM dbo.AssetAll WHERE SrcId IN (SELECT SrcId FROM dbo.SrcSys WHERE SrcSysNm = 'ProductDetail' and SrcTypCd = 'F')
union 
SELECT * FROM dbo.AssetAll WHERE SrcId IN (SELECT SrcId FROM dbo.SrcSys WHERE SrcFileTagNm='WHM_ASSET') and CoRSSecCd like 'OTHER:%'
) t
