SELECT * FROM dbo.Asset WHERE SrcId IN (SELECT SrcId FROM dbo.SrcSys WHERE SrcSysNm='CRS' and SrcFileTagNm='CRS_ASSETS')
