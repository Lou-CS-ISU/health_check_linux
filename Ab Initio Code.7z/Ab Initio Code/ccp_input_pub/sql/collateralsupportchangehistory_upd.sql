UPDATE HistSchema.CollateralSupportChangeHistory
SET
ModAtrbtNm	:=ModAtrbtNm
,ModAtrbtLabelNm	:=ModAtrbtLabelNm
,OldVal	:=OldVal
,NewVal	:=NewVal
,Comment	:=Comment
,SrcId	:=SrcId
,CrteUserNm	:=CrteUserNm
,CrteTs	:=CrteTs
,UserMchnAddr	:=UserMchnAddr
,UpdtUserNm	:=UpdtUserNm
,UpdtTs	:=UpdtTs
 WHERE ColtralSmryId = :ColtralSmryId
