select * from dbo.AssetAll where SrcId in (select SrcId from dbo.SrcSys where SrcSysNm ='ProductDetail')
