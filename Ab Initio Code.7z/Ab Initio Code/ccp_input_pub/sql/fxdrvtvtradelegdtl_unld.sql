select 
BuyAmt,
BuyCrncyId,
BuySellInd,
CallAmt,
CallCrncyId,
CashStldDt,
ContractRate,
DeliveryDt,
DownBarrierInOrOut,
DownBarrierLvl,
ExchgRate,
ExpiryDt,
ExrcsTypId,
FirstExrcsDt,
FlowDt,
MrkCalcDt,
MrkCrncyId,
MrkInCrncyAmt,
MtmAmt,
NetSI,
OptnDt,
OptnTypId,
PFEFirstExrcsDt,
PremiumAmt,
PremiumCrncyId,
PremiumDt,
p.ProductId,
ProductSubTypId,
PutAmt,
PutCrncyId,
PVDInd,
Rate,
RebateOrPayoutAmt,
RebateOrPayoutCrncyId,
SellAmt,
SellCrncyId,
SpotDelta,
SpotDt,
SpotRate,
StlmtCrncyId,
StlmtDt,
StlmtTypId,
StrikePrice,
SwapIndFarDealNbr,
SwapIndNearDealNbr,
TransactionId,
TransactionLegId,
UpBarrierInOut,
UpBarrierLvl,
ValDt,
g1.GnrcClassVal as g1_ExrcsTypId,
g2.GnrcClassVal as g2_OptnTypId,
g3.GnrcClassVal as g3_StlmtTypId,
cu1.CrncyISOCd as cu1_BuyCrncyId,
cu2.CrncyISOCd as cu2_CallCrncyId,
cu3.CrncyISOCd as cu3_MrkCrncyId,
cu4.CrncyISOCd as cu4_PutCrncyId,
cu5.CrncyISOCd as cu5_RebateOrPayoutCrncyId,
cu6.CrncyISOCd as cu6_SellCrncyId,
cu7.CrncyISOCd as cu7_stlmtCrncyId,
p.ProductNm
from [CoRSINPUT].[dbo].TransFXLeg t 
  LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g1
   ON t.ExrcsTypId = g1.[GnrcClassId]
   LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu1
   on t.BuyCrncyId = cu1.CrncyId
     LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu2
   on t.CallCrncyId  = cu2.CrncyId
    LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu3
   on t.MrkCrncyId  = cu3.CrncyId
      LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu4
   on t.PutCrncyId   = cu4.CrncyId
      LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu5
   on t.RebateOrPayoutCrncyId  = cu5.CrncyId
      LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu6
   on t.SellCrncyId  = cu6.CrncyId
      LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu7
   on t.stlmtCrncyId   = cu7.CrncyId
               LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g2
       ON t.[OptnTypId] = g2.[GnrcClassId]
	               LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g3
       ON t.StlmtTypId = g3.[GnrcClassId]
	    LEFT JOIN (SELECT [ProductId] As ProductID
      ,[ProductNm] As ProductNm
      ,[ProductHierarchyTypNm]
      FROM [CoRSINPUT].[dbo].[Product]
UNION
SELECT [ProductClassId] As ProductID
      ,[ProductClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
        FROM [CoRSINPUT].[dbo].[ProductClass]
UNION
SELECT [ProductGrpId] As ProductID
      ,[ProductGrpNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductGroup]
UNION
SELECT [ProductSubClassId] As ProductID
      ,[ProductSubClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductSubclass]) p
  ON T.[ProductId]= p.ProductID
