

UPDATE dbo.TransLoanTradedMoneyMarket
   SET TransactionId = :TransactionId, 
      PrntEntyId = :PrntEntyId, 
      SubEntyId = :SubEntyId, 
      SubEntyNm = :SubEntyNm, 
      IssuerNm = :IssuerNm, 
      MvInCrncyAmt = :MvInCrncyAmt, 
      GLTradeDtAcctId = :GLTradeDtAcctId,
      GLStlDtAcctId   = :GLStlDtAcctId,
      OrgnlParInCrncyAmt = :OrgnlParInCrncyAmt, 
      MktPriceAmt = :MktPriceAmt, 
      LongShortId = :LongShortId, 
      MvInUSDAmt = :MvInUSDAmt, 
      OrgnlParCrncyId = :OrgnlParCrncyId, 
      AssetId = :AssetId,
      SecIdTyp =  :SecIdTyp
      AssetSrcId = :AssetSrcId
      SecAssetCd = :SecAssetCd
      SecId     = :SecId
      CrteUserNm = :CrteUserNm
      CrteTs    = :CrteTs
      UserMchnAddr = :UserMchnAddr, 
      UpdtUserNm = :UpdtUserNm, 
      UpdtTs = :UpdtTs 
 WHERE TransactionId = :TransactionId 
