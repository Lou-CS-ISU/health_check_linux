INSERT INTO CustomerHierarchy
(CustomerId,CustomerHierarchyTypId,PrntCustomerId,RiskOwnrshpPct,RltnpTypNm,DBPrntClntNbr,SrcBsnsDt,SrcId,CrteUserNm,CrteTs,UserMchnAddr,UpdtUserNm,UpdtTs)
VALUES
(:CustomerId,:CustomerHierarchyTypId,:PrntCustomerId,:RiskOwnrshpPct,:RltnpTypNm,:DBPrntClntNbr,:SrcBsnsDt,:SrcId,:CrteUserNm,:CrteTs,:UserMchnAddr,:UpdtUserNm,:UpdtTs)
