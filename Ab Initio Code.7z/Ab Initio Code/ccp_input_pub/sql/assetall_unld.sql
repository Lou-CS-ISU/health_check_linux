select * from 
(
select * from dbo.AssetAll where SrcId in (select SrcId from dbo.SrcSys where SrcSysNm='TDCS') and CoRSSecCd like 'OTHER%'
union 
select * from dbo.AssetAll where SrcId not in (select SrcId from dbo.SrcSys where SrcSysNm='TDCS')  
) as temp
