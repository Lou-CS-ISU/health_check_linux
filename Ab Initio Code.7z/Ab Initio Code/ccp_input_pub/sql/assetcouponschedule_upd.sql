UPDATE dbo.AssetCouponSchedule SET
	[AssetId] = :AssetId
	,[CpnRate] = :CpnRate
	,[BgnDt] = :BgnDt
	,[EndDt] = :EndDt
	,[SrcId] = :SrcId
	,[UpdtUserNm] = :UpdtUserNm
	,[UpdtTs] = :UpdtTs
WHERE AssetCpnSchedId = :AssetCpnSchedId
