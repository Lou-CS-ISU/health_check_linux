
UPDATE dbo.TransIRPFETransaction
   SET TransactionId = :TransactionId                                                              
      ,BusinessDate = :BusinessDate                                                                
      ,ExchangeId = :ExchangeId                                                                    
      ,SwapDealer = :SwapDealer                                                                                                              
      ,TracerId = :TracerId                                                                        
      ,SwapDealerRef1 = :SwapDealerRef1                                                            
      ,SwapDealerRef2 = :SwapDealerRef2                                                            
      ,SwapDealerRef3 = :SwapDealerRef3                                                            
      ,ShortDesc = :ShortDesc                                                                      
      ,RegistrationDate = :RegistrationDate                                                        
      ,NumberCoupons = :NumberCoupons                                                              
      ,UnsettledCoupons = :UnsettledCoupons                                                        
      ,AdditionalPayments = :AdditionalPayments                                                    
      ,UnsettledAddPayments = :UnsettledAddPayments                                                
      ,PrincipalExchanges = :PrincipalExchanges                                                    
      ,UnsettledPrinExch = :UnsettledPrinExch                                                      
      ,NumberDealFinCenters = :NumberDealFinCenters                                                
      ,NumberAddDealFinCenters = :NumberAddDealFinCenters                                          
      ,NumberExchPrinFinCenters = :NumberExchPrinFinCenters                                        
      ,DayConvention = :DayConvention                                                              
      ,EndDateAdjustment = :EndDateAdjustment                                                      
      ,DaycountFraction = :DaycountFraction                                                        
      ,RateIndex = :RateIndex                                                                      
      ,Maturity = :Maturity                                                                        
      ,Spread = :Spread                                                                            
      ,ResetDateSpec = :ResetDateSpec                                                              
      ,CompoundType = :CompoundType                                                                
      ,FirstStubInterp = :FirstStubInterp                                                          
      ,LastStubInterp = :LastStubInterp                                                            
      ,FirstStubCmpPeriod = :FirstStubCmpPeriod                                                    
      ,LastStubCmpPeriod = :LastStubCmpPeriod                                                      
      ,FixedRate = :FixedRate                                                                      
      ,TimeZone = :TimeZone                                                                        
      ,ZeroCpnSwap = :ZeroCpnSwap                                                                  
      ,OisTypeSwap = :OisTypeSwap                                                                  
      ,RollDateConvention = :RollDateConvention                                                                                                                          
      ,UserMchnAddr = :UserMchnAddr                                                                
      ,UpdtUserNm = :UpdtUserNm                                                                    
      ,UpdtTs = :UpdtTs                                                                            
 WHERE  PFETransactionId = :PFETransactionId              



