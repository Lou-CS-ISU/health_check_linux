select * from dbo.AssetAll where SrcId in (select SrcId from dbo.SrcSys where SrcFileTagNm='SIMCORPWEST_ASSET' and SrcTypCd = 'F')
