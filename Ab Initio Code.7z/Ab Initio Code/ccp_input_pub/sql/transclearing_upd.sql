UPDATE [dbo].[TransClearing]
   SET 
      [ClearingCustomerId] = :ClearingCustomerId
      ,[ClearingCustomerLongNm] = :ClearingCustomerLongNm
      ,[ClearingCustomerShortNm] = :ClearingCustomerShortNm
      ,[ClearingPltfmNm] = :ClearingPltfmNm
      ,[ClearingPltfmTradeId] = :ClearingPltfmTradeId
      ,[ClearingTradeId] = :ClearingTradeId
      ,[HseIndTxt] = :HseIndTxt
      ,[FirmTxt] = :FirmTxt
      ,[ClassInd] = :ClassInd
      ,[SubClassInd] = :SubClassInd
      ,[AcctTypInd] = :AcctTypInd
      ,[TransactionTypeInd] = :TransactionTypeInd
      ,[CcpId] = :CcpId
      ,[ClearingBrkrId] = :ClearingBrkrId
      ,[ClearingBrkrNm] = :ClearingBrkrNm
      ,[ClearingBrkrTypId] = :ClearingBrkrTypId
      ,[SrcId] = :SrcId      
      ,[UserMchnAddr] = :UserMchnAddr
      ,[UpdtUserNm] = :UpdtUserNm
      ,[UpdtTs] = :UpdtTs
 WHERE TransactionId = :TransactionId
