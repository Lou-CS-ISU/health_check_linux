UPDATE dbo.Trans SET 
        SrcId                           = :SrcId,
        UserMchnAddr                    = :UserMchnAddr,
        UpdtUserNm                      = :UpdtUserNm,
        UpdtTs                          = :UpdtTs
        WHERE TransactionId             = :TransactionId 
