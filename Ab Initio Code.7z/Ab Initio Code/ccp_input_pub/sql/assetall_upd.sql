UPDATE [dbo].[AssetAll]
   SET [AssetNm] = ''
   where assetAllId=-12
