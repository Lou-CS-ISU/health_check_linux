select * from Asset A, SrcSys S where A.SrcId= S.SrcId and (S.SrcSysNm ='LoanIQ' and S.SrcFileTagNm ='LOANIQ_FAC' and  S.SrcTypCd ='F') 
