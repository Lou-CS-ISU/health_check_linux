SELECT Cust.[CustomerId],[CustomerShortNm],[CustomerHierarchyOrdrNbr]
       FROM [CoRSINPUT].[dbo].[Customer] Cust
	   INNER JOIN [CoRSINPUT].[dbo].[CustomerHierarchy] CustHier
	   ON Cust.[CustomerId] = CustHier.[CustomerId]
  AND CustHier.[CustomerHierarchyTypId] = 2417;
