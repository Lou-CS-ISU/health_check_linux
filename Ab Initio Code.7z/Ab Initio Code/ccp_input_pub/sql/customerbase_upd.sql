UPDATE CustomerBase
SET 
        CustomerBaseTypId = :CustomerBaseTypId
        ,UpdtUserNm = :UpdtUserNm
        ,UserMchnAddr = :UserMchnAddr
        ,UpdtTs = :UpdtTs
        ,SrcId = :SrcId

WHERE CustomerId = :CustomerId
