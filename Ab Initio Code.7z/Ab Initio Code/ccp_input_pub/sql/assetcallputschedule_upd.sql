UPDATE dbo.AssetCallPutSchedule SET
	[AssetId] = :AssetId
	,[CallPutTyp] = :CallPutTyp
	,[CallPutDt] = :CallPutDt
	,[CallPutPrice] = :CallPutPrice
	,[SrcId] = :SrcId
	,[UpdtUserNm] = :UpdtUserNm
	,[UpdtTs] = :UpdtTs
WHERE AssetCallPutSchedId = :AssetCallPutSchedId
