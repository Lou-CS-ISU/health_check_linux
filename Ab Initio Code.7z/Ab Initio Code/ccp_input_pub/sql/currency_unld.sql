select $['"' + string_join(record_info_item(dml_type_str = remove_fields(source_type = read_type(PROJECT+"/dml/"+string_downcase(TABLE_NAME)+".dml"), field_name_vec = "newline"), item = "name"),'","')+ '"']

from (select ROW_NUMBER() over (order by SrcId) row_num, 

$['"' + string_join(record_info_item(dml_type_str = remove_fields(source_type = read_type(PROJECT+"/dml/"+string_downcase(TABLE_NAME)+".dml"), field_name_vec = "newline"), item = "name"),'","')+ '"'] from $TABLE_NAME) x
