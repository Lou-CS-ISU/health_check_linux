UPDATE CustomerBase
SET 
        PortalFlg=1
	    ,ActvFlg=1

WHERE CustomerId = :CustomerId
