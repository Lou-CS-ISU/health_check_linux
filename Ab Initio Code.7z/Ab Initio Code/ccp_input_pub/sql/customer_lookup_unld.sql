SELECT [CustomerId]
      ,[CustomerShortNm]
      FROM [CoRSINPUT].[dbo].[Customer]
;
