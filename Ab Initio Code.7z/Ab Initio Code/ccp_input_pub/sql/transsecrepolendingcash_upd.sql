UPDATE dbo.TransSecRepoLendingCash
SET
 TransactionId = :TransactionId
,CashDrctnInd = :CashDrctnInd
,CashAccrualCrncyId = :CashAccrualCrncyId
,CashCrncyId = :CashCrncyId
,CashNotionalInCrncyAmt = :CashNotionalInCrncyAmt
,CashAccrualInCrncyAmt = :CashAccrualInCrncyAmt
,CashNotionalInUSDAmt = :CashNotionalInUSDAmt
,CashAccrualInUSDAmt = :CashAccrualInUSDAmt
,UserMchnAddr = :UserMchnAddr
,UpdtUserNm = :UpdtUserNm
,UpdtTs = :UpdtTs
WHERE RepoLndngCashId = :RepoLndngCashId
