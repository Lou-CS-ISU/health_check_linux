UPDATE dbo.TransDefaultFund SET
         DfltRqrdAmt                           = :DfltRqrdAmt,
        DFCExcsDfctAmt                          = :DFCExcsDfctAmt,
	UserMchnAddr                    = :UserMchnAddr,
        UpdtUserNm                      = :UpdtUserNm,
        UpdtTs                          = :UpdtTs
WHERE TransactionId = :TransactionId
