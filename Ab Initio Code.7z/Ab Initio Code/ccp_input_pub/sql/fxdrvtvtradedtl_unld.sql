  SELECT  [TransactionId]
           ,[LnkDealNbr]
        ,[InitialMrgnPct]
        ,[InternalStlmtFlg]
        ,[RvrsdLnkTrade]
        ,[RvrslInd]
        ,[ProductData1]
        ,[ProductData2]
        ,[ProductData3]
        ,[ProductData4]
        ,[ProductData5]
        ,[InitialIMAmt]
        ,[CustomerStatId],
  	  g2.GnrcClassVal as g2_CustomerStatId
      FROM [CoRSINPUT].[dbo].[TransFX] t
  	 LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g2
          ON T.CustomerStatId = g2.[GnrcClassId]
