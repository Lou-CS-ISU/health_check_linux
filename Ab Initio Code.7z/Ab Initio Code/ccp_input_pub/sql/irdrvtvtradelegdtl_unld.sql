  SELECT TransactionIRLegId as [TransIRLegId]
        ,[TransactionId]
        ,[CurrNotionalAmt]
        ,[MaturityDt]
        ,[NotionalAmt]
        ,[PayFreqCd]
        ,[RghtToPayFixedTyp]
        ,[UpfrontColtralAmt]
        ,[MvAmt]
        ,[BuySellInd]
        ,[CallCrncyId]
        ,[CallAmt]
        ,[OptnTypId]
        ,[OptnStrikePriceAmt]
        ,[PutAmt]
        ,[PutCrncyId]
        ,[Spread01Amt]
        ,[StrikePriceAmt]
        ,[LwrBndAmt]
        ,[LwrStrikeAmt]
        ,[UprBndAmt]
        ,[UprStrikeAmt]
        ,[PremiumAmt]
        ,[PremiumDt]
        ,[ExtrlOblgrId]
        ,[UndlyBondDesc]
        ,[UndlyMaturityDt]
        ,[UndlySecCd]
        ,[DgtlPfoffAmt]
        ,[Drtn]
        ,[RghtToPutCallId]
        ,[BuyCrncyId]
        ,[BuyCrncyAmt]
        ,[CashDt]
        ,[IRIndx1Id]
        ,[IRIndx2Id]
        ,[IRIndxCurve]
        ,[IRIndxVal1]
        ,[IRIndxVal2]
        ,[FPATyp]
        ,[FRARateAmt]
        ,[PayIndxId]
        ,[PayIndxTenorCd]
        ,[PayNotionalAmt]
        ,[PayRateOrSprdAmt]
        ,[PayCrncyId]
        ,CashStldFlg as [CashSetttledFlg]
        ,[PV01]
        ,[RcvCrncyId]
        ,[RcvFreqCd]
        ,[RcvIndxId]
        ,[RcvIndxTenorCd]
        ,[RcvNotionalAmt]
        ,[RcvRateOrSprdAmt]
        ,[RcvRateTypId]
        ,[RefEntySClldentifier]
        ,[RatchetRate]
        ,[UsedApexNotionalAmt]
        ,[AvgLifeLngth]
        ,[CptyLglEntyId]
        ,[FXRstFlg]
        ,[NotionalExchgFlg]
        ,[PrnclExchgCount]
        ,[RateSensitiyvityAmt]
        ,[RmangYears]
        ,[SellCrncyAmt]
        ,[SellCrncyId]
        ,[FirstExrcsDt]
        ,[LastExrcsDt]
        ,[ExrcsTypId]
        ,[OblgrId]
        ,[SecAssetCd]
        ,[AssetId]
        ,[AssetSrcId]
        ,[CashAmt]
        ,[SwapSubTypId]
        ,[ProductData1]
        ,[ProductData2]
        ,[LegProductTyp]
        ,[IRIndex1TenorCd]
        ,[BckOfcTransactionId]
        ,[SubordinatedLoanFlg]
        ,[StrctSubTypId]
        ,[PayRateTypId]
        ,[PayFixdFlg]
             ,[ProductSubTypId]
        ,[MtmAmt],
  	   g1.GnrcClassVal as g1_ExrcsTypId,
  g2.GnrcClassVal as g2_OptnTypId,
  g3.GnrcClassVal as g3_PayRateTypId,
     g4.GnrcClassVal as g4_RcvRateTypId,
  g5.GnrcClassVal as g5_StrctSubTypId,
  g6.GnrcClassVal as g6_SwapSubTypId,
  g7.GnrcClassVal as g7_RghtToPutCallCd,
  cu1.CrncyISOCd as cu1_BuyCrncyId,
  cu2.CrncyISOCd as cu2_CallCrncyId,
  cu3.CrncyISOCd as cu3_Paycrncyid,
  cu4.CrncyISOCd as cu4_PutCrncyId,
  cu5.CrncyISOCd as cu5_Rcvcrncyid,
  cu6.CrncyISOCd as cu6_SellCrncyId,
  p.ProductNm
    FROM [CoRSINPUT].[dbo].[TransIRLeg] t
  LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g1
     ON t.ExrcsTypId = g1.[GnrcClassId]
     LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu1
     on t.BuyCrncyId = cu1.CrncyId
       LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu2
     on t.CallCrncyId  = cu2.CrncyId
      LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu3
     on t.Paycrncyid  = cu3.CrncyId
        LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu4
     on t.PutCrncyId   = cu4.CrncyId
        LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu5
     on t.Rcvcrncyid  = cu5.CrncyId
        LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu6
     on t.SellCrncyId  = cu6.CrncyId
                 LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g2
         ON t.[OptnTypId] = g2.[GnrcClassId]
                         LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g3
         ON t.PayRateTypId = g3.[GnrcClassId]
  	            LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g4
         ON t.RcvRateTypId = g4.[GnrcClassId]
                         LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g5
         ON t.StrctSubTypId = g5.[GnrcClassId]
  	    LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g6
         ON t.swapsubTypId = g6.[GnrcClassId]
        LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g7
         ON t.RghtToPutCallId = g7.[GnrcClassId]
              LEFT JOIN (SELECT [ProductId] As ProductID
        ,[ProductNm] As ProductNm
        ,[ProductHierarchyTypNm]
        FROM [CoRSINPUT].[dbo].[Product]
  UNION
  SELECT [ProductClassId] As ProductID
        ,[ProductClassNm] As ProductNm
        ,[ProductHierarchyTypNm]
          FROM [CoRSINPUT].[dbo].[ProductClass]
  UNION
  SELECT [ProductGrpId] As ProductID
        ,[ProductGrpNm] As ProductNm
        ,[ProductHierarchyTypNm]
    FROM [CoRSINPUT].[dbo].[ProductGroup]
  UNION
  SELECT [ProductSubClassId] As ProductID
        ,[ProductSubClassNm] As ProductNm
        ,[ProductHierarchyTypNm]
    FROM [CoRSINPUT].[dbo].[ProductSubclass]) p
    ON T.[ProductId]= p.ProductID
