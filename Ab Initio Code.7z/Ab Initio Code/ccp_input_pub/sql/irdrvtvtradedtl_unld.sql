  SELECT [TransactionId]
        ,[ContractSprdAmt]
        ,[TransactionTyp]
        ,[ExrcsDtFreqTyp]
        ,[FirstExrcsDt]
        ,[LastExrcsDt]
        ,[AcctTyp]
        ,t.CntryCdId as [CntryId]
        ,[TransCustomerTyp]
        ,[DeliveryTyp]
        ,[FirmCd]
        ,[IndstCd]
        ,[RcvryRateAmt]
        ,[RmrkTxt]
        ,[RpstyCd]
        ,[RestructuringNm]
        ,[SetPltfmNm]
        ,[SeniorityTyp]
        ,[StdModFlg]
        ,[UCPLEId]
        ,[DeliveryDt]
        ,[AccrualPayRcvTypId]
        ,[ContractPriceAmt]
        ,[NotionalStruct]
        ,[PayRcvId]
        ,[TearUpInd]
        ,[TearUpDt]
        ,[MBSCCMatchingInd]
        ,[BnkNbr]
        ,[OblgrId]
        ,[OblgnId] , 
  	  g1.GnrcClassVal as g1_PayRcvId,
  g2.GnrcClassVal as g2_AccrualPayRcvTypId,
  cu1.CrncyISOCd as cu1_CrncyId,
  cu2.CntryCdId as cu2_CntryId
    FROM [CoRSINPUT].[dbo].[TransIR] t 
    LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g1
     ON t.PayRcvId = g1.[GnrcClassId]
     LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu1
     on t.CrncyId = cu1.CrncyId
       LEFT JOIN [CoRSINPUT].[dbo].[MasterCountryCodes] cu2
     on t.CntryCdId  = cu2.CntryCdId
                      LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g2
         ON t.AccrualPayRcvTypId = g2.[GnrcClassId]
