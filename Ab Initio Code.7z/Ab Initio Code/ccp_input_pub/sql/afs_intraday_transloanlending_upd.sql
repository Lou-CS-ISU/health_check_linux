UPDATE dbo.TransLoanLending SET
        IncldIndFlg                           = :IncldIndFlg,
		ExpsrinCrncyAmt                           = :ExpsrinCrncyAmt,
                ExpsrinUSDAmt                          = :ExpsrinUSDAmt,
		OstndInCrncyAmt                           = :OstndInCrncyAmt,
                OstndInUSDAmt                                   = :OstndInUSDAmt,
		NewExstgInd                           = :NewExstgInd,
        UserMchnAddr                    = :UserMchnAddr,
        UpdtUserNm                      = :UpdtUserNm,
        UpdtTs                          = :UpdtTs
WHERE TransactionId = :TransactionId
