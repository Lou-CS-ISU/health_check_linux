select * from dbo.Asset where SrcId in ( select SrcId  from dbo.SrcSys where SrcSysNm = 'ProductDetail' and SrctypCd = 'F')
