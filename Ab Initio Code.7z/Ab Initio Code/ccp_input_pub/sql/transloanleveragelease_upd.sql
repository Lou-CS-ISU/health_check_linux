update dbo.TransLoanLeverageLease set
OblgrId             = :OblgrId,
NetBookBalAmt       = :NetBookBalAmt,
OblgnNm             = :OblgnNm,
OblgnEfctDt         = :OblgnEfctDt,
MatDt               = :MatDt,
FaFacilityId        = :FaFacilityId,
ExpsrCrncyId        = :ExpsrCrncyId,
ExpsrInCrncyAmt     = :ExpsrInCrncyAmt,
ExpsrInUSDAmt       = :ExpsrInUSDAmt,
UserMchnAddr        = :UserMchnAddr,
UpdtTs              = :UpdtTs,
UpdtUserNm          = :UpdtUserNm
where 
TransactionId		= :TransactionId
