SELECT f.[TransactionId],t.[CoRSTransactionId],o.[OrgEntyIdNm],
   c.[CustomerShortNm],m.[CrncyISOCd],p.[ProductNm]
	  ,r.[RiskMsrLkpShortNm] AS RiskMsrNm
      ,[0D] as RiskMsrVal 
     ,[CoRSAgreementId]
      ,[BsnsDt]
	      
  FROM [CoRSOUTPUT].[dbo].[TradeTimePointRiskMeasure] f
  INNER JOIN [CoRSINPUT].[dbo].[RiskMeasureLKP] r
  ON f.[RiskMsrTypId] = r.[RiskMsrLkpId]
  INNER JOIN [CoRSINPUT].[dbo].[Trans] t
  ON t.[TransactionId] = f.[TransactionId]
  INNER JOIN [CoRSINPUT].[dbo].[Organization] o
  ON t.[LglEntyId] = o.[OrgId]
  INNER JOIN [CoRSINPUT].[dbo].[Customer] c
  ON c.[CustomerId] = t.[LglCustomerId]
  LEFT JOIN [CoRSINPUT].[dbo].[Currency] m
  ON m.[CrncyId] = t.[MrkCrncyId]
  INNER JOIN [CoRSINPUT].[dbo].[Product] p
  ON t.[ProductId] = p.[ProductId]
  LEFT JOIN [CoRSOUTPUT].[dbo].[TransOutput] ot
  ON t.[TransactionId] = ot.[TransactionId]
  LEFT JOIN [CoRSINPUT].[dbo].[CustomerAgreement] a
  ON ot.[CustomerAgreementId] = a.[CustomerAgreementId]
;
