UPDATE [dbo].[TransFX]
   SET 
      [SpotFrwrdInd] = :SpotFrwrdInd
      ,[LnkDealNbr] = :LnkDealNbr
      ,[InitialMrgnPct] = :InitialMrgnPct
      ,[InternalStlmtFlg] = :InternalStlmtFlg
      ,[RvrsdLnkTrade] = :RvrsdLnkTrade
      ,[RvrslInd] = :RvrslInd
      ,[ProductData1] = :ProductData1
      ,[ProductData2] = :ProductData2
      ,[ProductData3] = :ProductData3
      ,[ProductData4] = :ProductData4
      ,[ProductData5] = :ProductData5
      ,[InitialIMAmt] = :InitialIMAmt
      ,[CustomerStatId] = :CustomerStatId
      ,[UserMchnAddr] = :UserMchnAddr
      ,[UpdtUserNm] = :UpdtUserNm
      ,[UpdtTs] = :UpdtTs
 WHERE TransactionId = :TransactionId

