UPDATE dbo.AssetFloatInfo SET
	[AssetId] = :AssetId
	,[CpnFrmlTxt] = :CpnFrmlTxt
	,[BaseRateCd] = :BaseRateCd
	,[Sprd] = :Sprd
	,[CpnFreqCdInd] = :CpnFreqCdInd
	,[IndxNm] = :IndxNm
	,[Slope] = :Slope
	,[SrcId] = :SrcId
	,[UpdtUserNm] = :UpdtUserNm
	,[UpdtTs] = :UpdtTs
WHERE AssetFltInfoId = :AssetFltInfoId
