EXEC dbo.uspIpLimitCustMigrationMain 0,0,0,1;
