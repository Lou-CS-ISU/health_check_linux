SELECT
A.BsnsDayCnvntTxt
,A.CpnFreqTypId
,A.CpnRate
,A.CpnTypTxt
,A.FirstCpnPymntDt
,A.LastCpnPymntDt
,A.NextCpnRstDt
,A.CallPutInd
,A.CmnCd
,A.CUSIPCd
,A.AssetId
,A.ISINCd
,A.IssueCrncyId
,A.IssueDt
,A.IssuerId
,A.IssuerTickerCd
,A.MaturityDt
,A.MktPrice
,A.MktPriceCrncyId
,A.MktPriceDt
,A.MktPriceSrcNm
,A.AssetNm
,A.OthrCd
,A.ParVal
,A.PayInKindFlg
,A.SEDOLCd
,A.SinkableFlg
,A.TickerCd
,A.IssuerId
,A.CoRSSecCd -- Natural Key
,A.ProductTypCd
,S.[SrcFileTagNm] -- Natural Key 
,S.[SrcFileNm] -- Natural Key modified on 01/27/2017
,S.[SrcSysNm] -- Natural Key modified on 01/27/2017
,AH.AssetClassNm
,AH.AssetGrpNm
,AH.AssetSubTypNm
,AH.AssetTypNm
,AR.FitchRating
,AR.FitchRatingDt
,AR.ImpliedRating
,AR.ImpliedRatingDt
,AR.MstrRating
,AR.MstrRatingDt
,AR.MoodyRating
,AR.MoodyRatingDt
,AR.SPRating
,AR.SPRatingDt
,A.Eqty180VolatilityPct
FROM [CoRSINPUT].[dbo].[Asset] A
INNER JOIN [CoRSINPUT].[dbo].[SrcSys] S ON S.SrcId = A.SrcId
LEFT OUTER JOIN [CoRSINPUT].[dbo].[AssetRating] AR on A.AssetId = AR.AssetId
LEFT OUTER JOIN [CoRSINPUT].[dbo].[AssetHierarchy] AH on A.AssetHierarchyId = AH.AssetHierarchyId

