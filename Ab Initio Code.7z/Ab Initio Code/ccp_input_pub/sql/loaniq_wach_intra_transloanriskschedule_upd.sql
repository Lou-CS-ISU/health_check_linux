UPDATE [dbo].[TransLoanRiskSchedule]
   SET [EfctDt] = :EfctDt
      ,[RiskMitigatedPct] = :RiskMitigatedPct
      ,[TransactionId] = :TransactionId
      ,[UserMchnAddr] = :UserMchnAddr
      ,[UpdtUserNm] = :UpdtUserNm
      ,[UpdtTs] = :UpdtTs
WHERE TransactionLoanRiskSchedId= :TransactionLoanRiskSchedId
