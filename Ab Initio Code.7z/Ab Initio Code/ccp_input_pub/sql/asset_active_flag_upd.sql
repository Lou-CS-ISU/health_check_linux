UPDATE [dbo].[Asset]
SET   [ActvFlg] = :ActvFlg
       ,[UpdtUserNm] = :UpdtUserNm
       ,[UserMchnAddr] = :UserMchnAddr
       ,[UpdtTs] = :UpdtTs
WHERE
           [AssetId] = :AssetId;
