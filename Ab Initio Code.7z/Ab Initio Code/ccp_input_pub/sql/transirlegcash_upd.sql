UPDATE [dbo].[TransIRLegCash]
   SET ,[CashDt] = :CashDt
      ,[CashAmt] = :CashAmt
      ,[CrteUserNm] = :CrteUserNm
      ,[CrteTs] = :CrteTs, datetime
      ,[UserMchnAddr] = :UserMchnAddr
      ,[UpdtUserNm] = :UpdtUserNm
      ,[UpdtTs] = :UpdtTs
   WHERE
		TransIRLegCashId = :TransIRLegCashId;
