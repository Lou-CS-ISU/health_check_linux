
UPDATE dbo.TransIRPFETransFinCenter
   SET TransactionId = TransactionId                        
      ,BusinessDate = BusinessDate                          
      ,RecordId = RecordId                                  
      ,ExchangeId = ExchangeId                              
      ,SwapDealer = SwapDealer                                            
      ,TracerId = TracerId                                  
      ,FinanceCenter = FinanceCenter                        
      ,ProcessingtimeZone = ProcessingtimeZone             
      ,UserMchnAddr = UserMchnAddr                          
      ,UpdtUserNm = UpdtUserNm                              
      ,UpdtTs = UpdtTs                                      
 WHERE PFETransactionId = PFETransactionId    


