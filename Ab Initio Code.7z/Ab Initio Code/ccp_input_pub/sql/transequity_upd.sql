UPDATE [dbo].[TransEquity]
SET
VldStructProductFlg = :VldStructProductFlg,
VldToAgrgtFlg = :VldToAgrgtFlg,
UserMchnAddr = :UserMchnAddr,
UpdtUserNm = :UpdtUserNm,
UpdtTs = :UpdtTs
WHERE
TransactionId = :TransactionId
