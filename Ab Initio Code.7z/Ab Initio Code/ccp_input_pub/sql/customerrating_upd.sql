UPDATE CustomerRating
SET 

MstrRating = :MstrRating
,MoodyRatingOutlook = :MoodyRatingOutlook
,MoodyRating = :MoodyRating
,MoodyRatingTyp = :MoodyRatingTyp
,MoodyRatingWtchList = :MoodyRatingWtchList
,SPRating = :SPRating
,SPRatingOutlook = :SPRatingOutlook
,SPRatingWtchList = :SPRatingWtchList
,SPRatingTyp = :SPRatingTyp
,FitchRating = :FitchRating
,FitchOutlook = :FitchOutlook
,FitchRatingTyp = :FitchRatingTyp
,FitchRatingOutlook = :FitchRatingOutlook
,FitchRatingWtchList = :FitchRatingWtchList
,SrcId = :SrcId
,UpdtUserNm = :UpdtUserNm
,UserMchnAddr = :UserMchnAddr
,UpdtTs = :UpdtTs

WHERE CustomerId = :CustomerId
