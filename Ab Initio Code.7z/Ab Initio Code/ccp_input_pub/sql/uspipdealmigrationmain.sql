EXEC dbo.uspIpDealMigrationMain 0,0,0,1;
