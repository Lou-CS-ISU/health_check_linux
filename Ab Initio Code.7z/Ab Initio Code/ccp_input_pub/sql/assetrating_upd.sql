UPDATE [dbo].[AssetRating]
SET  [MstrRating] = :MstrRating
    ,[MstrRatingDt] = :MstrRatingDt
    ,[MoodyRating] = :MoodyRating
    ,[MoodyRatingDt] = :MoodyRatingDt
    ,[SPRating] = :SPRating
    ,[SPRatingDt] = :SPRatingDt
    ,[FitchRating] = :FitchRating
    ,[FitchRatingDt] = :FitchRatingDt
    ,[ImpliedRating] = :ImpliedRating
    ,[ImpliedRatingDt] = :ImpliedRatingDt
    ,[UpdtUserNm] = :UpdtUserNm
    ,[UserMchnAddr] = :UserMchnAddr
    ,[UpdtTs] = :UpdtTs

WHERE
	[AssetId] = :AssetId
