 WITH Tree AS
(
  SELECT [OrgId], [OrgPrntId], 1 AS OrgLvl,
    CAST(STR([OrgId], 10) AS VARCHAR(900)) COLLATE Latin1_General_BIN2 AS pth
  FROM [CoRSINPUT].[dbo].[Organization]
  WHERE [OrgPrntId] IS NULL

  UNION ALL

  SELECT C.[OrgId], C.[OrgPrntId], P.OrgLvl + 1,
    CAST(P.pth + STR(C.[OrgId], 10) AS VARCHAR(900)) COLLATE Latin1_General_BIN2
  FROM Tree AS P
    JOIN [CoRSINPUT].[dbo].[Organization] AS C
      ON C.[OrgPrntId] = P.[OrgId]
)
SELECT T.OrgId, OrgLvl, C.[OrgEntyIdNm],
  NULLIF(SUBSTRING(pth,  1, 10) + 0, 0) AS Lvl1ID,
  C1.[OrgEntyIdNm] AS Lvl1EntyNm,
  NULLIF(SUBSTRING(pth, 11, 10) + 0, 0) AS Lvl2ID,
  C2.[OrgEntyIdNm] AS Lvl2EntyNm,
  NULLIF(SUBSTRING(pth, 21, 10) + 0, 0) AS Lvl3ID,
  C3.[OrgEntyIdNm] AS Lvl3EntyNm,
  NULLIF(SUBSTRING(pth, 31, 10) + 0, 0) AS Lvl4ID,
  C4.[OrgEntyIdNm] AS Lvl4EntyNm,
  NULLIF(SUBSTRING(pth, 41, 10) + 0, 0) AS Lvl5ID,
  C5.[OrgEntyIdNm] AS Lvl5EntyNm
FROM Tree AS T
JOIN [CoRSINPUT].[dbo].[Organization] AS C
ON T.OrgId = C.OrgId
 LEFT JOIN [CoRSINPUT].[dbo].[Organization] AS C1
 ON NULLIF(SUBSTRING(pth,  1, 10) + 0, 0) = C1.OrgId
 LEFT JOIN [CoRSINPUT].[dbo].[Organization] AS C2
 ON NULLIF(SUBSTRING(pth,  11, 10) + 0, 0) = C2.OrgId
 LEFT JOIN [CoRSINPUT].[dbo].[Organization] AS C3
 ON NULLIF(SUBSTRING(pth,  21, 10) + 0, 0) = C3.OrgId
 LEFT JOIN [CoRSINPUT].[dbo].[Organization] AS C4
 ON NULLIF(SUBSTRING(pth,  31, 10) + 0, 0) = C4.OrgId
 LEFT JOIN [CoRSINPUT].[dbo].[Organization] AS C5
 ON NULLIF(SUBSTRING(pth,  41, 10) + 0, 0) = C5.OrgId
;
