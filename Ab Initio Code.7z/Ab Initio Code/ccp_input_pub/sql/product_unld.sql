select ProductHierarchyTypNm as ProductHierarchyLvlDesc,
ProductClassNm as ProductHierarchyLvlCCRMProductNm,
'ProductClass' as SrcTable
from dbo.ProductClass

union 

select ProductHierarchyTypNm as ProductHierarchyLvlDesc,
ProductSubClassNm as ProductHierarchyLvlCCRMProductNm,
'ProductSubClass' as SrcTable
from dbo.ProductSubClass

union 

select ProductHierarchyTypNm as ProductHierarchyLvlDesc,
ProductGrpNm as ProductHierarchyLvlCCRMProductNm,
'ProductGroup' as SrcTable
from dbo.ProductGroup

union 

select ProductHierarchyTypNm as ProductHierarchyLvlDesc,
ProductNm as ProductHierarchyLvlCCRMProductNm,
'Product' as SrcTable
from dbo.Product

