select
 Cust.CustomerId 
,Cust.BranchFlg
,Cust.CustomerTypId
,CustomerAdditionalAttribute.CERCptyType1Txt
,CustomerAdditionalAttribute.CERUltmtOblgrCntryCd
,CustomerPortal.AgntFlg
,CustomerPortal.AnlRvwDt
,Cust.CntryDomicileId
,Cust.CntryOfHdqtrId
,Cust.CntryOfRiskId
,CustomerPortal.DelrFlg
,Cust.CustomerNm
,CustomerPortal.IntraCntryBqrId
,Cust.CityNm
,Cust.BranchLocId
,CustomerRating.MstrRating
,CustomerAdditionalAttribute.CntryOfPrnclBsnsAddrId
,CustomerAdditionalAttribute.CustomerRegRptGrpTxt
,CustomerAdditionalAttribute.RegRptCptyTypTxt
,Cust.CustomerShortNm
,CustomerBase.CoRSCustomerId
,CustomerAdditionalAttribute.CntryOfIncId
,Cust.DunsNbrTxt
,Cust.FnclInstnAssetOvr100BFlg
,CustomerRating.FitchRating
,CustomerRating.FitchOutlook
,CustomerRating.SrcBsnsDt
,CustomerRating.FitchRatingOutlook
,CustomerRating.FitchRatingTyp
,CustomerRating.FitchRatingWtchList
,CustomerAdditionalAttribute.FR2436CntrlCptyFlg
,CustomerAdditionalAttribute.FR2436RptInstnFlg
,Cust.FXSpecNm
,CustomerAdditionalAttribute.HCLRCLCptyTypTxt
,Cust.LglEntyIdTxt
,Cust.LglOrgDesc
,Cust.MgdAcctFlg
,CustomerRating.MoodyRatingOutlook
,CustomerRating.MoodyRatingTyp
,CustomerRating.MoodyRatingWtchList
,CustomerRating.MoodyRating
,Cust.NAICSIndstCd
,CustomerAdditionalAttribute.NonPrftFlg
,CustomerAdditionalAttribute.OECDFlg
,Cust.PtrtActCrtfyFlg
,CustomerAdditionalAttribute.PSEGovFlg
,Cust.RegOCptyFlg
,CustomerAdditionalAttribute.RegulatedFnclInstnFlg
,Cust.RegWCptyFlg
,CustomerRating.SPRating
,Cust.SICIndstCd
,CustomerAdditionalAttribute.SvrgnFlg
,CustomerRating.SPRatingOutlook
,CustomerRating.SPRatingTyp
,CustomerRating.SPRatingWtchList
,CustomerAdditionalAttribute.SPECnsldPrntContrPartyTypTxt
,Cust.StckTicker
,Cust.WebAddrTxt
,CustomerPortal.BsnsCntctId1Nbr
,CustomerPortal.BsnsCntctId2Nbr
,CustomerPortal.RiskOfcrId
,CustomerPortal.LastRvwDt
,Cust.CustomerSubtypId as CustomerSubtypeId
,Cust.BsnsTypId
,CustomerPortal.HedgeFundFlg
,Cust.TaxIdNbr
,CustAlias.aliasid AS CptyCidId
 from dbo.Customer as Cust 
 left join dbo.CustomerPortal as CustomerPortal on Cust.CustomerId = CustomerPortal.CustomerId
 left join dbo.CustomerAdditionalAttribute as CustomerAdditionalAttribute on CustomerAdditionalAttribute.CustomerId = Cust.CustomerId
 left join dbo.CustomerRating as CustomerRating on CustomerRating.CustomerId = Cust.CustomerId
 left join dbo.CustomerBase as CustomerBase on CustomerBase.CustomerId = Cust.CustomerId 
 left join dbo.CustomerAlias custalias on CustAlias.customerid = CustomerBase.customerid and CustAlias.SysCd = 'CIDBA'

