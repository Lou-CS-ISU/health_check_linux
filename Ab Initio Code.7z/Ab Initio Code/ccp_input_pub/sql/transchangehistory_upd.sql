UPDATE HistSchema.TransChangeHistory
   SET ModAtrbtNm       = :ModAtrbtNm
      ,ModAtrbtLabelNm  = :ModAtrbtLabelNm
      ,OldVal           = :OldVal
      ,NewVal           = :NewVal
      ,Comment          = :Comment
      ,SrcId            = :SrcId
      ,CrteTs           = :CrteTs
      ,CrteUserNm       = :CrteUserNm
      ,UserMchnAddr     = :UserMchnAddr
      ,UpdtUserNm       = :UpdtUserNm
      ,UpdtTs           = :UpdtTs
 WHERE SrcId            = :SrcId
--TransactionId    = :TransactionId
