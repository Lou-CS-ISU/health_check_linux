UPDATE [dbo].[TransCreditUnderlyingDetail]
   SET [RefEntySCIId] = :RefEntySCIId
      ,[CCPTicker ] = :CCPTicker
      ,[SeniorityTyp] = :SeniorityTyp
      ,[RefOblgnId] = :RefOblgnId
      ,[RcvryRate] = :RcvryRate
      ,[RestructuringTyp] = :RestructuringTyp
      ,[SrcAssetCd] = :SrcAssetCd
      ,[SrcId] = :SrcId
      ,[UserMchnAddr] = :UserMchnAddr
      ,[UpdtUserNm] = :UpdtUserNm
      ,[UpdtTs] = :UpdtTs
 WHERE TransCreditUndlyDtlId = :TransCreditUndlyDtlId
