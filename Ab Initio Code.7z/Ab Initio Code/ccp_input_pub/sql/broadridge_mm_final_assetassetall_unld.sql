SELECT * FROM dbo.AssetAll WHERE SrcId IN (SELECT SrcId FROM dbo.SrcSys WHERE SrcSysNm= 'ProductDetail' and SrctypCd = 'F');
