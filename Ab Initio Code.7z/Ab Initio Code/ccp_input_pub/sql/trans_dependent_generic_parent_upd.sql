-- table_name_placeholder to be replaced by child table name
update dbo.table_name_placeholder  
set 
UpdtTs				=:UpdtTs,
UpdtUserNm			=:UpdtUserNm
where 
TransactionId			=:TransactionId
