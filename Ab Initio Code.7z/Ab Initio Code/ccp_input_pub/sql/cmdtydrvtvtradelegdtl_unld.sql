   SELECT T.TransactionCmdtyLegId as [TransCmdtyLegId] 
        ,T.[TransactionId]
        ,T.[CmdtyTyp]
        ,T.[BuySellInd]
        ,T.[OptnTypId]
        ,T.[TradePrice]
        ,T.[QtyUntTxt]
        ,T.[CrncyId]
        ,T.[PayCmdtyNm]
        ,T.[RcvCmdtyNm]
        ,T.[PayFreqTxt]
        ,T.RcvFreqTxt as [RecieveFreqTxt] 
        ,T.[CashStldFlg]
        ,T.[EfctDt]
        ,T.[FirstExrcsDt]
        ,T.[LastExrcsDt]
        ,T.[ExrcsTypId]
        ,T.[OptnCashStldFlg]
        ,T.[FixingTypTxt]
        ,T.[SwapCashStldTxt]
        ,T.[StlmtTypId]
        ,T.[PayFixingTypTxt]
        ,T.[RcvFixingTypTxt]
        ,T.PayRateTypId as [PayRateTyp]  
        ,T.RcvRateTypId as [RcvRateTyp]  
        ,T.[PayRateOrSprdAmt]
        ,T.[RcvRateOrSprdAmt]
        ,T.[RghtToPayFixdFlg]
        ,T.[StrikePrice]
        ,T.[CashStldDt]
        ,T.[ConfirmStatTxt]
        ,T.[ExpiryDt]
        ,T.[OptnDt]
        ,T.[OptnSubtypId] as OptnSubtypeId
        ,T.[StlmtDt]
        ,T.[PremiumDt]
        ,T.[ValDt]
        ,T.[PFETransactionID]
        ,T.[IndxPct]
        ,T.[CoRSCmdtyIndxNm]
        ,T.[PayACIndxNm]
        ,T.[RcvACIndxNm]
        ,T.[PayIndxPct]
        ,T.[RcvIndxPct]
        ,T.[PFERstDt]
        ,T.[PremiumAmt]
        ,T.ProcessOrg as [ProcOrg] 
        ,T.[UndlyEntyTradeID]
        ,T.[UnpaidPremiumAmt]
        ,T.[UndlySwapFlowLegIndxNm]
        ,T.[UndlySwapFltLegIndxPct]
        ,T.[UndlySwapFlowLegIndxPct]
        ,T.[ProductId]
        ,T.[ProductSubTypId]
        ,T.[SrcId]
  	  ,g1.GnrcClassVal as g_BuySellInd,
  	  g2.GnrcClassVal as g_ExrcsTypId,
  	  g3.GnrcClassVal as g_OptnSubtypeId,
  	  g4.GnrcClassVal as g_OptnTypId,
  	  g5.GnrcClassVal as g_StlmtTypId,
  	  cu.CrncyISOCd as CrncyISOCd,
  	  s.SrcFileNm,
  	  s.SrcFileTagNm,
  	  s.SrcSysNm,
  	  p.ProductNm
    FROM [CoRSINPUT].[dbo].[TransCommodityLeg] T
       LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g1
     ON T.BuySellInd = g1.[GnrcClassId]
     LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu
  ON T.CrncyId = cu.[CrncyId]
          LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g2
          ON T.ExrcsTypId = g2.[GnrcClassId]
             LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g3
         ON T.[OptnSubtypId] = g3.[GnrcClassId] 
  	          LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g4
         ON T.[OptnTypId] = g4.[GnrcClassId]
  	          LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g5
         ON T.StlmtTypId = g5.[GnrcClassId]
  	    LEFT JOIN (select [SrcSysNm],[SrcFileNm],[SrcFileTagNm],srcid from 
  		 [CoRSINPUT].[dbo].SrcSys) s
  		on T.srcid=s.srcid  
          LEFT JOIN (SELECT [ProductId] As ProductID
        ,[ProductNm] As ProductNm
        ,[ProductHierarchyTypNm]
        FROM [CoRSINPUT].[dbo].[Product]
  UNION
  SELECT [ProductClassId] As ProductID
        ,[ProductClassNm] As ProductNm
        ,[ProductHierarchyTypNm]
          FROM [CoRSINPUT].[dbo].[ProductClass]
  UNION
  SELECT [ProductGrpId] As ProductID
        ,[ProductGrpNm] As ProductNm
        ,[ProductHierarchyTypNm]
    FROM [CoRSINPUT].[dbo].[ProductGroup]
  UNION
  SELECT [ProductSubClassId] As ProductID
        ,[ProductSubClassNm] As ProductNm
        ,[ProductHierarchyTypNm]
    FROM [CoRSINPUT].[dbo].[ProductSubclass]) p
    ON T.[ProductId]= p.ProductID
  
