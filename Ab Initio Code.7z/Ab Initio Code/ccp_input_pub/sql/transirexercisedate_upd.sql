UPDATE [dbo].[TransIRExerciseDate]
SET
BckOfcTransId = :BckOfcTransId,
ExerciseDt = :ExerciseDt,
RpstyNm = :RpstyNm,
UserMchnAddr = :UserMchnAddr,
UpdtUserNm = :UpdtUserNm,
UpdtTs = :UpdtTs
 WHERE
       TransIRExerciseDtId = :TransIRExerciseDtId
