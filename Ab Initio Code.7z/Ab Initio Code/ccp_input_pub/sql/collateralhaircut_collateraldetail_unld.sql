select * from dbo.CollateralDetail where SrcId in (select SrcId from dbo.SrcSys where SrcSysNm ='Algo' and SrcTypCd='S')
