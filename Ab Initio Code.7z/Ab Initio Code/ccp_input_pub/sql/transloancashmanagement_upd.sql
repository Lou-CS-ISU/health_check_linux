UPDATE [dbo].[TransLoanCashManagement]
   SET [TransactionId] = :TransactionId
      ,[NostroBnkIdCd] = :NostroBnkIdCd
      ,[NostroBnkNm] = :NostroBnkNm
      ,[AcctNbr] = :AcctNbr
      ,[TransBalAmt] = :TransBalAmt
      ,[CurrExpsrInCrncyAmt] = :CurrExpsrInCrncyAmt
      ,[ExpsrAmtInUSD] = :ExpsrAmtInUSD
      ,[TransCrncyId] = :TransCrncyId
      ,[ExpsrCrncyId] = :ExpsrCrncyId
      ,[UpdtUserNm] = :UpdtUserNm
      ,[UserMchnAddr] = :UserMchnAddr
      ,[UpdtTs] = :UpdtTs
 WHERE
       TransactionId = :TransactionId
