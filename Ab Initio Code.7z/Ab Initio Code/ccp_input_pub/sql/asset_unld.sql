select * from dbo.Asset  
