UPDATE dbo.CollateralSummary
SET
InitialMrgnRqrmtAmt		  =:InitialMrgnRqrmtAmt
,InitialMrgnRqrmtGvnRcvTxt =:InitialMrgnRqrmtGvnRcvTxt
,InitialMrgnRqrmtOrgnlAmt =:InitialMrgnRqrmtOrgnlAmt
,InitialMrgnRqrmtOrgnlGvnRcvTxt =:InitialMrgnRqrmtOrgnlGvnRcvTxt
,UserMchnAddr                   =:UserMchnAddr
,UpdtUserNm                     =:UpdtUserNm
,UpdtTs                         =:UpdtTs

where ColtralSmryId =:ColtralSmryId
