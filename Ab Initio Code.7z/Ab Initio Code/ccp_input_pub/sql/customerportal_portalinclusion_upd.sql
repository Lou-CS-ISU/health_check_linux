UPDATE CustomerPortal
SET    ActvFlg=1

WHERE CustomerId = :CustomerId
