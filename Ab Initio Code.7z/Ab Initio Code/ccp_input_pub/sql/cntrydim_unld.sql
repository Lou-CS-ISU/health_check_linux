
select
MasterCountryCodes.CntryCdId
,MasterCountryCodes.CntryCd
,MasterCountryCodes.CntryNm
,MasterCountryCodes.IndustrializedFlg
,MasterCountryCodes.CnsldFlg
,MasterCountryCodes.GuidelinesExclusionsTypId
,MasterCountryCodes.CntryRiskOfcrId
,MasterCountryCodes.CrncyId
,CountryRating.CntryRiskRating
,CountryRating.CntryRiskDt
,CountryRating.CntryRiskOutlook
,CountryRating.SPLTRating
,CountryRating.SPSTRating
,CountryRating.SPOutlook
,CountryRating.SPRatingDt
,CountryRating.MoodyLTRating
,CountryRating.MoodySTRating
,CountryRating.MoodyOutlook
,CountryRating.MoodyRatingDt
,CountryRating.FitchSTRating
,CountryRating.FitchLTRating
,CountryRating.FitchOutlook
,CountryRating.FitchRatingDt
,CountryRating.EIUCntryRiskRating
,CountryRating.EIUCntryRiskRatingDt
,CountryRating.InstnInvstScore
,CountryRating.InstnInvstRnk
,CountryRating.InstnInvstDt
,CountryRating.NmnlGDP
,CountryRating.ICERCRating
,CountryRating.ICERCDt
from dbo.MasterCountryCodes
join dbo.CountryRating
on CountryRating.CntryCdId = MasterCountryCodes.CntryCdId


