  select CoRSAgreementId as AgreementId,
         OrgEntyIdNm as WfOrgId,
  	   customerlglentyidNmP as CptyIdP,
  	   customerlglentyidNmS as CptyIdS,
         ProductNm AS ProductIdP,
  	   ProductHierarchyTypNm AS ProductIdS,
  	   AgreementDt as AgreementBsnsDt,
  	   LocLevel3Nm as LocId,
  	   LocLevel3Nm as CntryLocNm
   from 
  (select cust_agm.*,cust_agm_org.orgId,cust_agm_cust.CustomerId,cust_agm_prod.ProductId,Corsinp_custagmcntry.CntryCdId,Corsinp_custagm_crncy.crncyid
  from
  (SELECT [CustomerAgreementId], WLEId as [WfLglEntyId] ,[CustomerLglEntyId],CoRSAgreementId,AgreementDt FROM [CoRSINPUT].[dbo].[CustomerAgreement]) cust_agm
  
  Left Join
  
  (SELECT [CustomerAgreementId],OrgId FROM [CoRSINPUT].[dbo].CustomerAgreementOrganization) cust_agm_org
  on cust_agm_org.CustomerAgreementId = cust_agm.CustomerAgreementId
     and cust_agm_org.[OrgId] = cust_agm.[WfLglEntyId]
  
  left join
  
  (sELECT CustomerAgreementId,CustomerId FROM [CoRSINPUT].[dbo].CustomerAgreementCustomer) cust_agm_cust
    on cust_agm_cust.CustomerAgreementId = cust_agm.CustomerAgreementId
      --and cust_agm_cust.[CustomerId] = cust_agm.[CustomerLglEntyId]
  
  left join
  
  (SELECT CustomerAgreementId,ProductId FROM [CoRSINPUT].[dbo].CustomerAgreementProduct) cust_agm_prod
        on cust_agm_prod.CustomerAgreementId = cust_agm.CustomerAgreementId
  
  Left Join
  
  (select  CustomerAgreementId,CntryCdId from [CoRSINPUT].[dbo].CustomerAgreementCountry) Corsinp_custagmcntry
  on Corsinp_custagmcntry.CustomerAgreementId = cust_agm.CustomerAgreementId
  
  left join 
  (select  CustomerAgreementId,CrncyId from [CoRSINPUT].[dbo].CustomerAgreementCurrency) Corsinp_custagm_crncy
  on Corsinp_custagm_crncy.CustomerAgreementId = cust_agm.CustomerAgreementId
  
  
  ) Agreeemntprtcp
  
   Left Join
    
    (Select CustomerId,CoRSCustomerid AS customerlglentyidNmP  from [CoRSINPUT].[dbo].CustomerBase) CoRSInpAgm_Cust
     on Agreeemntprtcp.customerlglentyid = CoRSInpAgm_Cust.CustomerId
  
  
   Left Join
    
    (Select CustomerId,CoRSCustomerid AS customerlglentyidNmS  from [CoRSINPUT].[dbo].CustomerBase) CoRSInp_Cust
     on Agreeemntprtcp.customerid = CoRSInp_Cust.CustomerId
  
    left join
    
    (Select OrgId,OrgEntyIdNm from [CoRSINPUT].[dbo].Organization) CoRSInp_Org
          on Agreeemntprtcp.wflglentyid = CoRSInp_Org.OrgId
  
    Left Join
  
    (Select ProductId,ProductNm,ProductHierarchyTypNm from [CoRSINPUT].[dbo].Product) Corsinpt_prod
    on  Agreeemntprtcp.ProductId = Corsinpt_prod.ProductId
  
  Left Join 
  
  (select  CntryCdId,CntryCd,cntryNm,LocId,LocLevel3Nm  from [CoRSINPUT].[dbo].MasterCountryCodes
  left join
  [CoRSINPUT].[dbo].Location
  on cntryNm = LocLevel3Nm) Corsinp_cntry
  on Agreeemntprtcp.CntryCdId = Corsinp_cntry.CntryCdId
  
  left join 
  (select CrncyId,CrncyISOCd from [CoRSINPUT].[dbo].Currency)  Corsinp_crncy
  on Agreeemntprtcp.CrncyId= Corsinp_crncy.CrncyId 
