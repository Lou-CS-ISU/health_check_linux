SELECT  [LimitId]
      ,[PrtflioCubeId]
      ,g1.[GnrcClassVal] as PrtflioCubeNm
      ,l.[CustomerId]
      ,c1.[CustomerShortNm] as CptyNm
      ,l.[CntryCdId]
      ,cw.[CntryNm]
      ,l.[WLEntyId]
      ,o.[OrgEntyIdNm]
      ,[CptyId]
      ,c2.[CustomerShortNm] as TrdngCptyNm
      ,l.[ProductID]
      ,p.ProductNm
      ,p.[ProductHierarchyTypNm]
	  ,l.[LimitCrncyId]
	  ,cu.[CrncyISOCd]
      ,l.[RiskMeasureLkpId]
      ,r.[RiskMsrLkpShortNm]
      ,l.[PeakUtilAmt]
	  ,l.[TmBandNm]
	  ,l.[LimitVal]

  FROM (
SELECT o.[LimitId]
          ,[PrtflioCubeId]
          ,[CustomerId]
          ,[CntryCdId]
          ,WLEId as [WLEntyId]
          ,[CptyId]
          ,coalesce([ProductId],[ProductGrpId],[ProductClassId],[ProductSubClassId]) as ProductId
          ,RiskMsrLkpId as [RiskMeasureLkpId]
		  ,[LimitCrncyId]
		  ,coalesce([PeakUtilAmt],0) as PeakUtilAmt
		  ,[TmBandNm]
		  ,[LimitVal]
          FROM  [CoRSINPUT].[dbo].[Limit] i
		  INNER JOIN [CoRSOUTPUT].[dbo].[LimitOutput] o
		  ON i.[LimitId] = o.[LimitId]
		  and o.[BsnsDt] = '${CCP_RPT_PUB_BUSINESS_DATE}'
      ) l
  LEFT JOIN [CoRSINPUT].[dbo].[GnrcClass] g1
   ON l.[PrtflioCubeId] = g1.[GnrcClassId]
        LEFT JOIN  [CoRSINPUT].[dbo].[Customer] c1
        ON l.[CustomerId] = c1.[CustomerId]
        LEFT JOIN [CoRSINPUT].[dbo].[MasterCountryCodes] cw
        ON l.[CntryCdId] = cw.[CntryCdId]
        LEFT JOIN [CoRSINPUT].[dbo].[Organization] o
        ON l.[WLEntyId] = o.[OrgId]
        LEFT JOIN  [CoRSINPUT].[dbo].[Customer] c2
        ON l.[CptyId] = c2.[CustomerId]
        LEFT JOIN (SELECT [ProductId] As ProductID
      ,[ProductNm] As ProductNm
      ,[ProductHierarchyTypNm]
      FROM [CoRSINPUT].[dbo].[Product]
UNION
SELECT [ProductClassId] As ProductID
      ,[ProductClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
        FROM [CoRSINPUT].[dbo].[ProductClass]
UNION
SELECT [ProductGrpId] As ProductID
      ,[ProductGrpNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductGroup]
UNION
SELECT [ProductSubClassId] As ProductID
      ,[ProductSubClassNm] As ProductNm
      ,[ProductHierarchyTypNm]
  FROM [CoRSINPUT].[dbo].[ProductSubclass]) p
  ON l.[ProductId]= p.ProductID
LEFT JOIN [CoRSINPUT].[dbo].[RiskMeasureLKP] r
ON l.[RiskMeasureLkpId] = r.[RiskMsrLkpId]
LEFT JOIN [CoRSINPUT].[dbo].[Currency] cu
ON l.LimitCrncyId = cu.[CrncyId]
;
