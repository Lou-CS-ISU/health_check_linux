EXEC dbo.UpdateLkpValId;
