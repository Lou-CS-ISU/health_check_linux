SELECT * FROM dbo.Asset WHERE SrcId IN (SELECT SrcId FROM dbo.SrcSys WHERE SrcFileTagNm='SIMCORPWEST_ASSET' and SrcTypCd = 'F')
