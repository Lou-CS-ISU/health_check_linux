UPDATE dbo.TransOwnerRoleAssoc
   SET OwnerRoleTypId = :OwnerRoleTypId                                            
      ,OwnerNm = :OwnerNm                                                          
      ,OwnerId = :OwnerId                                                          
      ,UpdtUserNm = :UpdtUserNm                           
      ,UserMchnAddr =:UserMchnAddr                           
      ,UpdtTs = :UpdtTs                                                            
 WHERE  TransactionOwnerRoleAsctnId =:TransactionOwnerRoleAsctnId 
