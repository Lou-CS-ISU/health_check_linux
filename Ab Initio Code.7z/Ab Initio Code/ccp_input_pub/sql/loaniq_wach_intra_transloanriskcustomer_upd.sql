UPDATE [dbo].[TransLoanRiskCustomer]
   SET
       [RiskMtgntTypId]   = :RiskMtgntTypId
      ,[UserMchnAddr]   = :UserMchnAddr
      ,[UpdtUserNm]     = :UpdtUserNm
      ,[UpdtTs]         = :UpdtTs
 WHERE TransactionId    = :TransactionId AND
       CustomerId       = :CustomerId
