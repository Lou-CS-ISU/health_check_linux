UPDATE [dbo].[TransEquitySAMIVolatility]
SET
RicCode = :RicCode,
IndexTicker = :IndexTicker,
Volatility180days = :Volatility180days,
SAMIBusinessDate = :SAMIBusinessDate,
BusinessDate = :BusinessDate,
UserMchnAddr = :UserMchnAddr,
UpdtUserNm = :UpdtUserNm,
UpdtTs = :UpdtTs
WHERE
TransSAMIVolatilityId = :TransSAMIVolatilityId
