UPDATE dbo.CollateralSummary
SET
BsnsDt                    =:BsnsDt
,InitialMrgnAmt                   =:InitialMrgnAmt
,InitialMrgnGvnRcvTxt     =:InitialMrgnGvnRcvTxt
,InitialMrgnRqrmtAmt              =:InitialMrgnRqrmtAmt
,InitialMrgnRqrmtGvnRcvTxt =:InitialMrgnRqrmtGvnRcvTxt
,TotColtralInCrncyAmt                   =:TotColtralInCrncyAmt
,ColtralGvnRcvTxt                       =:ColtralGvnRcvTxt
,TotColtralInUSDAmt                     =:TotColtralInUSDAmt
,TotAdjstColtralInCrncyAmt   =:TotAdjstColtralInCrncyAmt
,TotAdjstColtralInUSDAmt                =:TotAdjstColtralInUSDAmt
,TotVrtnMrgnAmt                         =:TotVrtnMrgnAmt
,TotVrtnMrgnGvnRcvTxt                   =:TotVrtnMrgnGvnRcvTxt
,VrtnMrgnRqrmtAmt                       =:VrtnMrgnRqrmtAmt
,VrtnMrgnRqrmtGvnOrRcvTxt       =:VrtnMrgnRqrmtGvnOrRcvTxt
,VltnDt                                         =:VltnDt
,UnsettledVrblMrgnAmt							=:UnsettledVrblMrgnAmt
,ExcsDfctAmt                         =:ExcsDfctAmt
,ColtralMvAmt                    =:ColtralMvAmt
,SrcId                                          =:SrcId
,ProcessStatId   = :ProcessStatId
,UserMchnAddr    = :UserMchnAddr
,UpdtUserNm      = :UpdtUserNm
,UpdtTs  = :UpdtTs
where ColtralSmryId =:ColtralSmryId
