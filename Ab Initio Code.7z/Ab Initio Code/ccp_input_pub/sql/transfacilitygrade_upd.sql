UPDATE [dbo].[TransFacilityGrade]
   SET 
BQRSbstnRsnId                   = :BQRSbstnRsnId
,RatingTypId                    = :RatingTypId
,RatingCd                       = :RatingCd
,RatingEfctDt                   = :RatingEfctDt
,PriorityCd                     = :PriorityCd
,RatingAmt                      = :RatingAmt
,RatingPct                      = :RatingPct
,AsgnrId                        = :AsgnrId
,CoRSSrcId                      = :CoRSSrcId
,SrcId                          = :SrcId
,UserMchnAddr                   = :UserMchnAddr
,UpdtUserNm                     = :UpdtUserNm
,UpdtTs                         = :UpdtTs
 WHERE TransactionFacilityGrdId = :TransactionFacilityGrdId
