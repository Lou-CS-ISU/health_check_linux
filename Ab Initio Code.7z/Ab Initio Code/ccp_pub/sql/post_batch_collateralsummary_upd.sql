UPDATE dbo.CollateralSummary
SET
        ProcessStatId = :proc_stat_id
        
WHERE ColtralSmryId = :ColtralSmryId
