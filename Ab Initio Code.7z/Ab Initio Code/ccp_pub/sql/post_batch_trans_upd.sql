UPDATE dbo.Trans
SET
        ProcessStatId = isnull(ProcessStatId,:proc_stat_id)
        ,CCRMFltrRuleFrcRjctTxt = isnull(CCRMFltrRuleFrcRjctTxt,:excpn_id)
WHERE TransactionId = :TransactionId
