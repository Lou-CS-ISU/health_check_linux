SELECT 'Global' "division_qname", ec.Name "error_code_name", m.Name "metric_name"
FROM ${MHUB_MAINSCHEMA}.AbDQErrorCodeMetric xref
INNER JOIN ${MHUB_MAINSCHEMA}.AbDQMetric m
ON m.DQMetricID = xref.DQMetricID
INNER JOIN ${MHUB_MAINSCHEMA}.AbDQErrorCode ec
ON ec.DQErrorCodeID = xref.DQErrorCodeID
