SELECT 'Global' "division_qname", dl.xDispositionLookupID, sys.Name "system_name", appl.Name "application_name", 
ds.SourcePath "dataset_rpath", de.QualifiedName "field_name", ec.Name "issue_code", 
disp.Name "disposition", sev.SeverityLevel "severity"
FROM ${MHUB_MAINSCHEMA}.AbxDispositionLookup dl
LEFT OUTER JOIN ${MHUB_MAINSCHEMA}.AbDQErrorCode ec
ON ec.DQErrorCodeID = dl.DQErrorCodeID
LEFT OUTER JOIN ${MHUB_MAINSCHEMA}.AbSystem sys
ON sys.SystemID = dl.SystemID
LEFT OUTER JOIN ${MHUB_MAINSCHEMA}.AbApplication appl
ON appl.ApplicationID = dl.ApplicationID
LEFT OUTER JOIN ${MHUB_MAINSCHEMA}.AbDataSet ds
ON ds.DataSetID = dl.DataSetID
LEFT OUTER JOIN ${MHUB_MAINSCHEMA}.AbDataElem de
ON de.DataElemID = dl.DataElemID
LEFT OUTER JOIN ${MHUB_MAINSCHEMA}.AbxDispositionType disp
ON disp.xDispositionTypeID = dl.xDispositionTypeID
LEFT OUTER JOIN ${MHUB_MAINSCHEMA}.AbxSeverity sev
ON sev.xSeverityID = dl.xSeverityID
