SELECT div.QualifiedName "division_qname", met.Name "name", met.DQMetricID "dqmetricid"
FROM ${MHUB_MAINSCHEMA}.DQMetric met
INNER JOIN ${MHUB_MAINSCHEMA}.AbDivision div
ON div.DivisionID = met.DivisionID
