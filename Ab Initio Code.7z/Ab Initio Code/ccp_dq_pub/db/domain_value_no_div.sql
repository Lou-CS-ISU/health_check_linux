SELECT 'Global' "division_qname", dcs.Name "domain_codeset_name", dcv.Value "value", 
dcv.ActiveDate "activedate", dcv.ExpiryDate "expirydate",
dcs.ObjectPropertyTypeID "objectpropertytypeid"
FROM ${MHUB_MAINSCHEMA}.AbDomainCodeSet dcs
INNER JOIN ${MHUB_MAINSCHEMA}.AbDomainCodeValue dcv
ON dcv.DomainCodeSetID = dcs.DomainCodeSetID
WHERE dcv.Value is not NULL
