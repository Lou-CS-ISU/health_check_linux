SELECT 'Global' "division_qname", code.Name "issuecode", class.Name "errorclass"
FROM ${MHUB_MAINSCHEMA}.AbxErrorClass class
INNER JOIN ${MHUB_MAINSCHEMA}.AbDQErrorCode code
ON code.xErrorClassID = class.xErrorClassID

