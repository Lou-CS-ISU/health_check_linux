SELECT 'Global' "division_qname", Name "name", DQMetricID "dqmetricid"
FROM ${MHUB_MAINSCHEMA}.DQMetric
