MERGE [dbo].[CustomerHierarchy] ch
			USING CoRSINPUT_PRD.dbo.CustomerHierarchy chp
			ON ch.CustomerId =chp.CustomerId AND ch.CustomerHierarchyTypId=chp.CustomerHierarchyTypId
			WHEN MATCHED THEN
			UPDATE SET 
			CustomerHierarchyTypId =chp.CustomerHierarchyTypId,
			PrntCustomerId =chp.PrntCustomerId,
			RiskOwnrshpPct =chp.RiskOwnrshpPct,
			RltnpTypNm =chp.RltnpTypNm,
			DBPrntClntNbr =chp.DBPrntClntNbr,
			SrcBsnsDt =chp.SrcBsnsDt,
			SrcId =chp.SrcId,
			CrteUserNm =chp.CrteUserNm,
			CrteTs =chp.CrteTs,
			UserMchnAddr =chp.UserMchnAddr,
			UpdtUserNm =chp.UpdtUserNm,
			UpdtTs =chp.UpdtTs
			
			WHEN NOT MATCHED THEN
				INSERT 
				(
				CustomerId,				 
				CustomerHierarchyTypId,
				PrntCustomerId,
				RiskOwnrshpPct,
				RltnpTypNm,
				DBPrntClntNbr,
				SrcBsnsDt,
				SrcId,
				CrteUserNm,
				CrteTs,
				UserMchnAddr,
				UpdtUserNm,
				UpdtTs				 
				)
				VALUES
				(
				 
				
				  CustomerId ,
				  CustomerHierarchyTypId ,
				  PrntCustomerId ,
				  RiskOwnrshpPct ,
				  RltnpTypNm ,
				  DBPrntClntNbr ,
				  SrcBsnsDt ,
				  SrcId, 
				  'etl_uat_CoRS_RW'
				,SYSDATETIME()
				,@@SERVERNAME
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				);;;;
          
          
          
          