MERGE [dbo].[CustomerFacilityGrade] cfg
			USING CoRSINPUT_PRD.dbo.CustomerFacilityGrade cfgp
			on cfg.CustomerFacilityGrdId=cfgp.CustomerFacilityGrdId

			WHEN MATCHED THEN
			UPDATE SET 
			CustomerId =cfgp.CustomerId,
			ProductTypId =cfgp.ProductTypId,
			WLEId =cfgp.WLEId,
			BQRId =cfgp.BQRId,
			CQRId =cfgp.CQRId,
			AprvrId =cfgp.AprvrId,
			DtOfAprvl =cfgp.DtOfAprvl,
			DtOfEnty =cfgp.DtOfEnty,
			BQRSbstnRsnId =cfgp.BQRSbstnRsnId,
			AQRId =cfgp.AQRId,
			FacilityGrdSrcIdNbr =cfgp.FacilityGrdSrcIdNbr,
			CptyId =cfgp.CptyId,
			ProductTypInd =cfgp.ProductTypInd,
			SrcId =cfgp.SrcId,
			CrteUserNm =cfgp.CrteUserNm,
			CrteTs =cfgp.CrteTs,
			UserMchnAddr =cfgp.UserMchnAddr,
			UpdtUserNm =cfgp.UpdtUserNm,
			UpdtTs =cfgp.UpdtTs
			
			WHEN NOT MATCHED THEN
				INSERT 
				(
                                        CustomerId,
                                        ProductTypId,
                                        WLEId,
                                        BQRId,
                                        CQRId,
                                        AprvrId,
                                        DtOfAprvl,
                                        DtOfEnty,
                                        BQRSbstnRsnId,
                                        AQRId,
                                        FacilityGrdSrcIdNbr,
                                        CptyId,
                                        ProductTypInd,
                                        SrcId,
                                        CrteUserNm,
                                        CrteTs,
                                        UserMchnAddr,
                                        UpdtUserNm,
                                        UpdtTs
				)
				VALUES
				(
                                        CustomerId,
                                        ProductTypId,
                                        WLEId,
                                        BQRId,
                                        CQRId,
                                        AprvrId,
                                        DtOfAprvl,
                                        DtOfEnty,
                                        BQRSbstnRsnId,
                                        AQRId,
                                        FacilityGrdSrcIdNbr,
                                        CptyId,
                                        ProductTypInd,
                                        SrcId,
				  'etl_uat_CoRS_RW'
				,SYSDATETIME()
				,@@SERVERNAME
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				);;;;
          
          
          
          
