INSERT INTO CntryCodesWICS 
        (cntryCd
        ,cntryNm
        ,status
        ,cntryCode3
        ,OECDMbrFlg
        ,CRCFlg
        ,vldInd
        ,vrsnCmnt
        ,srcId
        ,recTs
        ,userNm
        ,userMchnId
        ,oprtnCd
        ,srcBsnsDt
        ,lastUpdtDt
        ,vrsnEfctDt
        )
VALUES (:cntryCd
        ,:cntryNm
        ,:status
        ,:cntryCode3
        ,:OECDMbrFlg
        ,:CRCFlg
        ,:vldInd
        ,:vrsnCmnt
        ,:srcId
        ,:recTs
        ,:userNm
        ,:userMchnId
        ,:oprtnCd
        ,:srcBsnsDt
        ,:lastUpdtDt
        ,:vrsnEfctDt
        )

