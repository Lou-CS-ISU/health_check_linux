SELECT * FROM dbo.crdStageCMR WHERE businessDate=$business_date;
