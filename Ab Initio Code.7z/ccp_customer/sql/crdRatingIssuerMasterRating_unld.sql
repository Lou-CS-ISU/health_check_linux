SELECT * FROM dbo.crdRatingIssuerMasterRating 
WHERE businessDate=$business_date and projectId='ADAPTIV_ISSUER' and agency in ('MOODYS', 'SP', 'FITCH');

