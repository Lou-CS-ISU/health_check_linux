UPDATE HistSchema.CustomerParentChangeHistory
SET 
OldPrntCustomerId       = :OldPrntCustomerId    
,OldPrntCustomerNm      = :OldPrntCustomerNm          
,OldRiskOwnrshpPct      = :OldRiskOwnrshpPct     
,NewPrntCustomerId      = :NewPrntCustomerId
,NewPrntCustomerNm      = :NewPrntCustomerNm         
,NewRiskOwnrshpPct      = :NewRiskOwnrshpPct         
,CustomerChngHistId     = :CustomerChngHistId        
,UpdtUserNm             = :UpdtUserNm         
,UserMchnAddr           = :UserMchnAddr     
,UpdtTs                 = :UpdtTs         
WHERE 
CustomerPrntChngHistId  = :CustomerPrntChngHistId
