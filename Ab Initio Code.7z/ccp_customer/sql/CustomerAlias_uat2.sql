MERGE [dbo].[CustomerAlias] ca
			USING CoRSINPUT_PRD.dbo.CustomerAlias cap
			ON ca.CustomerId = cap.CustomerId and  ca.SrcId = cap.SrcId
			WHEN MATCHED THEN
			UPDATE SET 
			 AliasId =cap.AliasId,
          BsnsAcctNm =cap.BsnsAcctNm,
          CreditSCI =cap.CreditSCI,
          TradeAdvncWICS =cap.TradeAdvncWICS,
          PrevCustomerId =cap.PrevCustomerId,
          SrcBsnsDt =cap.SrcBsnsDt,
          SysCd =cap.SysCd,
         
          CrteUserNm =cap.CrteUserNm,
          CrteTs =cap.CrteTs,
          UserMchnAddr =cap.UserMchnAddr,
          UpdtUserNm =cap.UpdtUserNm,
          UpdtTs =cap.UpdtTs
			
			
			WHEN NOT MATCHED THEN
				INSERT 
				(
    CustomerId,
    AliasId,
    BsnsAcctNm,
    CreditSCI,
    TradeAdvncWICS,
    PrevCustomerId,
    SrcBsnsDt,
    SysCd,
    SrcId,
    CrteUserNm,
    CrteTs,
    UserMchnAddr,
    UpdtUserNm,
    UpdtTs
)
				VALUES
				(
				  CustomerId ,
				  AliasId, 
                   BsnsAcctNm ,
				  CreditSCI, 
				  TradeAdvncWICS ,
				  PrevCustomerId
                  , SrcBsnsDt
                   ,SysCd 
                  ,SrcId 
                   ,'etl_uat_CoRS_RW', 
					SYSDATETIME(),
					@@SERVERNAME,
					'etl_uat_CoRS_RW',
					SYSDATETIME()
);;;;