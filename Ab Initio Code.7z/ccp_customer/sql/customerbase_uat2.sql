MERGE [dbo].[Customerbase] cb
			USING CoRSINPUT_PRD.dbo.Customerbase cbp
			ON cb.CoRSCustomerId = cbp.CoRSCustomerId
			WHEN MATCHED THEN
			UPDATE SET 
					   cb.CustomerBaseTypId = cbp.CustomerBaseTypId,
					   cb.CrteUserNm = cbp.CrteUserNm,
					   cb.CrteTs = cbp.CrteTs,
					   cb.UserMchnAddr = cbp.UserMchnAddr,
					   cb.UpdtUserNm = cbp.UpdtUserNm,
					   cb.UpdtTs = cbp.UpdtTs
					   
			WHEN NOT MATCHED THEN
				INSERT 
				(
					
	
							CoRSCustomerId,
							CustomerBaseTypId,
							SrcId,
							CrteUserNm,
							CrteTs,
							UserMchnAddr,
							UpdtUserNm,
							UpdtTs
    
						)
					VALUES
						(
   
							cbp.CoRSCustomerId,
							cbp.CustomerBaseTypId,
							cbp.SrcId,
							'etl_uat_CoRS_RW', -- CrteUserNm - varchar
							SYSDATETIME(),
							@@SERVERNAME,
							'etl_uat_CoRS_RW',
							SYSDATETIME()
						);;;;