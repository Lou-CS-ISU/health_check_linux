UPDATE CustomerHierarchy
      SET 
          PrntCustomerId = :PrntCustomerId,
          RiskOwnrshpPct = :RiskOwnrshpPct,
          RltnpTypNm = :RltnpTypNm,
          SrcId = :SrcId,
          UserNm = :UserNm,
          UserMchnAddr = :UserMchnAddr,
          UpdtTs = :UpdtTs,
          DBPrntClntNbr = :DBPrntClntNbr,
          CustomerHierarchyTypId = :CustomerHierarchyTypId
      WHERE
            CustomerId = :CustomerId 
            and SrcId = :SrcId
         
