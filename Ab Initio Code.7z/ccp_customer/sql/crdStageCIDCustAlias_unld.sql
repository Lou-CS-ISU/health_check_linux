SELECT * FROM dbo.crdStageCIDCustAlias WHERE businessDate=$business_date;
