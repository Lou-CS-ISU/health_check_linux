INSERT INTO CustomerAlias
        (customerId
        ,aliasId
        ,prevCustomerId
        ,sysCd
        ,bsnsAcctNm
        ,creditSCI
        ,tradeAdvncWICS
        ,vldInd
        ,vrsnCmnt
        ,srcId
        ,recTs
        ,userNm
        ,userMchnId
        ,oprtnCd
        ,srcBsnsDt
        ,lastUpdtDt
        ,vrsnEfctDt

        )
VALUES (
        :customerId
        ,:aliasId
        ,:prevCustomerId
        ,:sysCd
        ,:bsnsAcctNm
        ,:creditSCI
        ,:tradeAdvncWICS
        ,:vldInd
        ,:vrsnCmnt
        ,:srcId
        ,:recTs
        ,:userNm
        ,:userMchnId
        ,:oprtnCd
        ,:srcBsnsDt
        ,:lastUpdtDt
        ,:vrsnEfctDt

        )

