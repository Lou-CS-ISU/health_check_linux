MERGE [dbo].[CustomerPortal] cp
			USING CoRSINPUT_PRD.dbo.CustomerPortal cpp
			ON cp.CustomerId = cpp.CustomerId
			WHEN MATCHED THEN
			UPDATE SET  RiskOfcrId =cpp.RiskOfcrId,
          DrvtvExcsRiskOfcrFlg =cpp.DrvtvExcsRiskOfcrFlg,
          FXExcsRiskOfcrFlg =cpp.FXExcsRiskOfcrFlg,
          BsnsCntctId1Nbr =cpp.BsnsCntctId1Nbr,
          BsnsCntctId2Nbr =cpp.BsnsCntctId2Nbr,
          AnlRvwDt =cpp.AnlRvwDt,
          LastRvwDt =cpp.LastRvwDt,
          CreditVltnAmtLqdtyId =cpp.CreditVltnAmtLqdtyId,
          IntraCntryBqrId =cpp.IntraCntryBqrId,
          AgntFlg =cpp.AgntFlg,
          DelrFlg =cpp.DelrFlg,
          HedgeFundFlg =cpp.HedgeFundFlg,
          ScrtzSpclPurpsEntyFlg =cpp.ScrtzSpclPurpsEntyFlg,
          RiskBlckCompStatFlg =cpp.RiskBlckCompStatFlg,
          DrvtvMndtyOvrdFlg =cpp.DrvtvMndtyOvrdFlg,
          Comment =cpp.Comment,
          CustomerIndstId =cpp.CustomerIndstId,
          CntryOfDomicileId =cpp.CntryOfDomicileId,
          CntryOfRiskId =cpp.CntryOfRiskId,
          DeskLimitRiskOfcrId =cpp.DeskLimitRiskOfcrId,
          AdtnlRptField1 =cpp.AdtnlRptField1,
          AdtnlRptField2 =cpp.AdtnlRptField2,
          AdtnlRptField3 =cpp.AdtnlRptField3,
          AdtnlRptField4 =cpp.AdtnlRptField4,
          SvrgnFlg =cpp.SvrgnFlg,
          ActvFlg =cpp.ActvFlg,
          CrteUserNm =cpp.CrteUserNm,
          CrteTs =cpp.CrteTs,
          UserMchnAddr =cpp.UserMchnAddr,
          UpdtUserNm =cpp.UpdtUserNm,
          UpdtTs =cpp.UpdtTs
			WHEN NOT MATCHED THEN
				INSERT 
				(
				 CustomerId,
					RiskOfcrId,
					DrvtvExcsRiskOfcrFlg,
					FXExcsRiskOfcrFlg,
					BsnsCntctId1Nbr,
					BsnsCntctId2Nbr,
					AnlRvwDt,
					LastRvwDt,
					CreditVltnAmtLqdtyId,
					IntraCntryBqrId,
					AgntFlg,
					DelrFlg,
					HedgeFundFlg,
					ScrtzSpclPurpsEntyFlg,
					RiskBlckCompStatFlg,
					DrvtvMndtyOvrdFlg,
					Comment,
					CustomerIndstId,
					CntryOfDomicileId,
					CntryOfRiskId,
					DeskLimitRiskOfcrId,
					AdtnlRptField1,
					AdtnlRptField2,
					AdtnlRptField3,
					AdtnlRptField4,
					SvrgnFlg,
					ActvFlg,
					SrcId,
					CrteUserNm,
					CrteTs,
					UserMchnAddr,
					UpdtUserNm,
					UpdtTs      	
				)
				VALUES
				(
				  CustomerId 
				  ,RiskOfcrId 
                  ,DrvtvExcsRiskOfcrFlg 
                  ,FXExcsRiskOfcrFlg 
                  ,BsnsCntctId1Nbr 
                  ,BsnsCntctId2Nbr 
                  ,AnlRvwDt 
                  ,LastRvwDt 
                  ,CreditVltnAmtLqdtyId 
                  ,IntraCntryBqrId 
                  ,AgntFlg 
                  ,DelrFlg 
                  ,HedgeFundFlg 
                  ,ScrtzSpclPurpsEntyFlg 
                  ,RiskBlckCompStatFlg 
                  ,DrvtvMndtyOvrdFlg 
                  ,Comment 
                  ,CustomerIndstId 
                  ,CntryOfDomicileId 
                  ,CntryOfRiskId 
                  ,DeskLimitRiskOfcrId 
                  ,AdtnlRptField1 
                 , AdtnlRptField2 
                 ,AdtnlRptField3 
                 ,AdtnlRptField4 
                 , SvrgnFlg 
                 ,ActvFlg 
                  ,SrcId 
                  ,'etl_uat_CoRS_RW'
				, SYSDATETIME()
				,@@SERVERNAME
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				);;;;