MERGE [dbo].[CustomerRating] cr
			USING CoRSINPUT_PRD.dbo.CustomerRating crp
			ON  cr.CustomerId = crp.CustomerId
			WHEN MATCHED THEN
			UPDATE SET 
		  MstrRating =crp.MstrRating,
          MoodyRatingOutlook =crp.MoodyRatingOutlook,
          MoodyRating =crp.MoodyRating,
          MoodyRatingTyp =crp.MoodyRatingTyp,
          MoodyRatingWtchList =crp.MoodyRatingWtchList,
          SPRating =crp.SPRating,
          SPRatingOutlook =crp.SPRatingOutlook,
          SPRatingWtchList =crp.SPRatingWtchList,
          SPRatingTyp =crp.SPRatingTyp,
          FitchRating =crp.FitchRating,
          FitchOutlook =crp.FitchOutlook,
          FitchRatingTyp =crp.FitchRatingTyp,
          FitchRatingOutlook =crp.FitchRatingOutlook,
          FitchRatingWtchList =crp.FitchRatingWtchList,
          SrcBsnsDt =crp.SrcBsnsDt,
          SrcId =crp.SrcId,
          CrteUserNm =crp.CrteUserNm,
          CrteTs =crp.CrteTs,
          UserMchnAddr =crp.UserMchnAddr,
          UpdtUserNm =crp.UpdtUserNm,
          UpdtTs =crp.UpdtTs
			WHEN NOT MATCHED THEN
				INSERT 
				(
				 CustomerId,
    MstrRating,
    MoodyRatingOutlook,
    MoodyRating,
    MoodyRatingTyp,
    MoodyRatingWtchList,
    SPRating,
    SPRatingOutlook,
    SPRatingWtchList,
    SPRatingTyp,
    FitchRating,
    FitchOutlook,
    FitchRatingTyp,
    FitchRatingOutlook,
    FitchRatingWtchList,
    SrcBsnsDt,
    SrcId,
    CrteUserNm,
    CrteTs,
    UserMchnAddr,
    UpdtUserNm,
    UpdtTs			 
				)
				VALUES
				(
				
				
    CustomerId ,
    MstrRating ,
    MoodyRatingOutlook ,
    MoodyRating ,
    MoodyRatingTyp ,
    MoodyRatingWtchList ,
    SPRating 
   ,SPRatingOutlook 
   ,SPRatingWtchList 
   ,SPRatingTyp 
   ,FitchRating 
   ,FitchOutlook 
   ,FitchRatingTyp 
   ,FitchRatingOutlook 
   ,FitchRatingWtchList 
   ,SrcBsnsDt
    ,SrcId 
     ,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				,@@SERVERNAME
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				);;;;