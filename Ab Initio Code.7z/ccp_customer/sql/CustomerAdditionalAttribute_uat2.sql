MERGE [dbo].[CustomerAdditionalAttribute] cat
			USING CoRSINPUT_PRD.dbo.CustomerAdditionalAttribute catp
			ON cat.CustomerId = catp.CustomerId
			WHEN MATCHED THEN
			UPDATE SET VrsnOrdrNbr =catp.VrsnOrdrNbr,
					   CustomerRegRptGrpTxt =catp.CustomerRegRptGrpTxt,
					   RegRptCptyTypTxt =catp.RegRptCptyTypTxt,
					   TICIntlOrgCd =catp.TICIntlOrgCd,
					   CERUltmtOblgrCntryCd =catp.CERUltmtOblgrCntryCd,
					   TICRgnlOrgCd =catp.TICRgnlOrgCd,
					   TICCntryCd =catp.TICCntryCd,
					   FnclInstnFlg =catp.FnclInstnFlg,
					   RegulatedFnclInstnFlg =catp.RegulatedFnclInstnFlg,
					   SPESbsdyBnkFlg =catp.SPESbsdyBnkFlg,
					   SPEMktFndngFlg =catp.SPEMktFndngFlg,
					   OECDFlg =catp.OECDFlg,
					   SvrgnFlg =catp.SvrgnFlg,
					   PSEGovFlg =catp.PSEGovFlg,
					   NonPrftFlg =catp.NonPrftFlg,
					   SPEWCISFlg =catp.SPEWCISFlg,
					   FR2436RptInstnFlg =catp.FR2436RptInstnFlg,
					   FR2436CntrlCptyFlg =catp.FR2436CntrlCptyFlg,
					   FR2436RefEntyTypTxt =catp.FR2436RefEntyTypTxt,
					   FR2436EqtyCptyRgnTxt =catp.FR2436EqtyCptyRgnTxt,
					   FR2436CDSCptyRgnTxt =catp.FR2436CDSCptyRgnTxt,
					   HCLRCLCptyTypTxt =catp.HCLRCLCptyTypTxt,
					   CERCptyType1Txt =catp.CERCptyType1Txt,
					   CERCptyType2Txt =catp.CERCptyType2Txt,
					   CMRSCIIdTxt =catp.CMRSCIIdTxt,
					   SPECnsldPrntContrPartyTypTxt =catp.SPECnsldPrntContrPartyTypTxt,
					   CntryOfPrnclBsnsAddrId =catp.CntryOfPrnclBsnsAddrId,
					   CntryOfIncId =catp.CntryOfIncId,
					   VrsnComment =catp.VrsnComment,
					   SrcBsnsDt =catp.SrcBsnsDt,
					   CntryRiskClassIdNbr =catp.CntryRiskClassIdNbr,
					   SrcId =catp.SrcId,
					   CrteUserNm =catp.CrteUserNm,
					   CrteTs =catp.CrteTs,
					   UserMchnAddr =catp.UserMchnAddr,
					   UpdtUserNm =catp.UpdtUserNm,
					   UpdtTs =catp.UpdtTs
					   					   
			WHEN NOT MATCHED THEN
				INSERT 
				(
    CustomerId,
    VrsnOrdrNbr,
    CustomerRegRptGrpTxt,
    RegRptCptyTypTxt,
    TICIntlOrgCd,
    CERUltmtOblgrCntryCd,
    TICRgnlOrgCd,
    TICCntryCd,
    FnclInstnFlg,
    RegulatedFnclInstnFlg,
    SPESbsdyBnkFlg,
    SPEMktFndngFlg,
    OECDFlg,
    SvrgnFlg,
    PSEGovFlg,
    NonPrftFlg,
    SPEWCISFlg,
    FR2436RptInstnFlg,
    FR2436CntrlCptyFlg,
    FR2436RefEntyTypTxt,
    FR2436EqtyCptyRgnTxt,
    FR2436CDSCptyRgnTxt,
    HCLRCLCptyTypTxt,
    CERCptyType1Txt,
    CERCptyType2Txt,
    CMRSCIIdTxt,
    SPECnsldPrntContrPartyTypTxt,
    CntryOfPrnclBsnsAddrId,
    CntryOfIncId,
    VrsnComment,
    SrcBsnsDt,
    CntryRiskClassIdNbr,
    SrcId,
    CrteUserNm,
    CrteTs,
    UserMchnAddr,
    UpdtUserNm,
    UpdtTs
)
				VALUES
				(
    CustomerId 
    ,VrsnOrdrNbr 
    ,CustomerRegRptGrpTxt 
    ,RegRptCptyTypTxt 
    ,TICIntlOrgCd 
    ,CERUltmtOblgrCntryCd 
    ,TICRgnlOrgCd 
    ,TICCntryCd 
    ,FnclInstnFlg 
    ,RegulatedFnclInstnFlg 
    ,SPESbsdyBnkFlg 
    ,SPEMktFndngFlg 
    ,OECDFlg 
    ,SvrgnFlg 
    ,PSEGovFlg 
    ,NonPrftFlg 
    ,SPEWCISFlg 
    ,FR2436RptInstnFlg 
    ,FR2436CntrlCptyFlg 
    ,FR2436RefEntyTypTxt 
    ,FR2436EqtyCptyRgnTxt 
    ,FR2436CDSCptyRgnTxt 
    ,HCLRCLCptyTypTxt 
    ,CERCptyType1Txt 
    ,CERCptyType2Txt 
    ,CMRSCIIdTxt 
    ,SPECnsldPrntContrPartyTypTxt 
    ,CntryOfPrnclBsnsAddrId 
    ,CntryOfIncId 
    ,VrsnComment 
   ,SrcBsnsDt
    ,CntryRiskClassIdNbr 
    ,SrcId 
 ,'etl_uat_CoRS_RW', 
SYSDATETIME(),
@@SERVERNAME,
'etl_uat_CoRS_RW',
SYSDATETIME()
);;;;