update CntryCodesWICS 
set    cntryCd = :cntryCd
        ,cntryNm = :cntryNm
        ,status = :status
        ,cntryCode3 = :cntryCode3
        ,OECDMbrFlg = :OECDMbrFlg
        ,CRCFlg = :CRCFlg
        --,vldInd = :vldInd
        --,vrsnCmnt = :vrsnCmnt
        ,srcId = :srcId
        ,recTs = :recTs
        ,userNm = :userNm
        ,userMchnId = :userMchnId
        ,oprtnCd = :oprtnCd
        ,srcBsnsDt = :srcBsnsDt
        ,lastUpdtDt = :lastUpdtDt
        ,vrsnEfctDt = :vrsnEfctDt

where cntryCd = :cntryCd

