SELECT * FROM dbo.crdStageSCICustDetail WHERE businessDate=$business_date;
