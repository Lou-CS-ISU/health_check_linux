MERGE [dbo].[CustomerReferenceAccount] cra 
			USING CoRSINPUT_PRD.dbo.CustomerReferenceAccount crap
			ON cra.CustomerRefAcctId = crap.CustomerRefAcctId
			WHEN MATCHED THEN
			UPDATE SET 
		
		CustomerId=crap.CustomerId,		
           WLEId =crap.WLEId,

          AcctNbrTxt =crap.AcctNbrTxt,
          Amt =crap.Amt,
          RefAcctId =crap.RefAcctId,
          SrcId =crap.SrcId,
          CrteUserNm =crap.CrteUserNm,
          CrteTs =crap.CrteTs,
          UserMchnAddr =crap.UserMchnAddr,
          UpdtUserNm =crap.UpdtUserNm,
          UpdtTs =crap.UpdtTs
		    WHEN NOT MATCHED THEN
				INSERT (
				
		  CustomerId,
    WLEId,
    AcctNbrTxt,
    Amt,
    RefAcctId,
    SrcId,
    CrteUserNm,
    CrteTs,
    UserMchnAddr,
    UpdtUserNm,
    UpdtTs
				
				) values
				
				
				(
				
     CustomerId ,
     WLEId,
    AcctNbrTxt ,
     Amt ,
     RefAcctId ,
     SrcId
     
    ,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				,@@SERVERNAME
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				
				)
				
				;;;;
				
