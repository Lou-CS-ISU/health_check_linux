UPDATE Customer
SET 

VrsnOrdrNbr = :VrsnOrdrNbr
,CustomerNm = :CustomerNm
,CustomerShortNm = :CustomerShortNm
,CustomerDesc = :CustomerDesc
,CustomerTypId = :CustomerTypId
,CustomerSubtypeId = :CustomerSubtypeId
,CntryDomicileId = :CntryDomicileId
,CntryCdId = :CntryCdId
,RegCntryOfDomicileId = :RegCntryOfDomicileId
,CntryOfHdqtrId = :CntryOfHdqtrId
,CntryOfRiskId = :CntryOfRiskId
,LglEntyIdTxt = :LglEntyIdTxt
,BranchFlg = :BranchFlg
,MultiInvstMngrFlg = :MultiInvstMngrFlg
,CircularInvstRlsFlg = :CircularInvstRlsFlg
,PtrtActCrtfyFlg = :PtrtActCrtfyFlg
,MgdAcctFlg = :MgdAcctFlg
,FnclInstnAssetOvr100BFlg = :FnclInstnAssetOvr100BFlg
,RegWCptyFlg = :RegWCptyFlg
,RegOCptyFlg = :RegOCptyFlg
,SICIndstCd = :SICIndstCd
,NAICSIndstCd = :NAICSIndstCd
,DunsNbrTxt = :DunsNbrTxt
,StckTicker = :StckTicker
,EntyTypDesc = :EntyTypDesc
,CityNm = :CityNm
,StNm = :StNm
,WebAddrTxt = :WebAddrTxt
,FXSpecNm = :FXSpecNm
,LglOrgDesc = :LglOrgDesc
,CustomerHierarchyOrdrNbr = :CustomerHierarchyOrdrNbr
,TaxIdNbr = :TaxIdNbr
,CustomerId = :CustomerId
,SrcId = :SrcId
,VrsnComment = :VrsnComment
,SrcBsnsDt = :SrcBsnsDt
,UserNm = :UserNm
,UserMchnAddr = :UserMchnAddr
,UpdtTs = :UpdtTs
,BranchLocId = :BranchLocId
,BsnsTypId = :BsnsTypId
,InvstMngrIdTxt = :InvstMngrIdTxt
,customerDescId = :customerDescId

WHERE CustomerId = :CustomerId
