INSERT INTO CustomerHierarchy
        (
        --CustomerHierarchyId
        chldCustomerId
        --,customerVrsnNbr
        ,vrsnOrdrNbr
        ,chldCustomerNm
        ,prntCustomerId
        ,prntCustomerNm
       -- ,customerHierarchyTypId
      --  ,customerHierarchyPath
        ,riskOwnrshpPct
        ,rltnpTyp
       ,efctDt
        ,expiryDt
      --  ,vldInd
      --  ,vrsnCmnt
        ,srcId
        ,recTs
        ,userNm
        ,userMchnId
        ,oprtnCd
        ,srcBsnsDt
        ,lastUpdtDt
        ,vrsnEfctDt
        )
VALUES (
        --:CustomerHierarchyId
        :chldCustomerId
    --    ,:customerVrsnNbr
        ,:vrsnOrdrNbr
        ,:chldCustomerNm
        ,:prntCustomerId
        ,:prntCustomerNm
   --     ,:customerHierarchyTypId
   --     ,:customerHierarchyPath
        ,:riskOwnrshpPct
        ,:rltnpTyp
        ,:efctDt
        ,:expiryDt
  --      ,:vldInd
 --       ,:vrsnCmnt
        ,:srcId
        ,:recTs
        ,:userNm
        ,:userMchnId
        ,:oprtnCd
        ,:srcBsnsDt
        ,:lastUpdtDt
        ,:vrsnEfctDt

        )

