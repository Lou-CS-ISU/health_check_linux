UPDATE CustomerAdditionalAttribute
SET 

VrsnOrdrNbr = :VrsnOrdrNbr
,CustomerRegRptGrpTxt = :CustomerRegRptGrpTxt
,RegRptCptyTypTxt = :RegRptCptyTypTxt
,TICIntlOrgCd = :TICIntlOrgCd
,CERUltmtOblgrCntryCd = :CERUltmtOblgrCntryCd
,TICRgnlOrgCd = :TICRgnlOrgCd
,TICCntryCd = :TICCntryCd
,FnclInstnFlg = :FnclInstnFlg
,RegulatedFnclInstnFlg = :RegulatedFnclInstnFlg
,SPESbsdyBnkFlg = :SPESbsdyBnkFlg
,SPEMktFndngFlg = :SPEMktFndngFlg
,OECDFlg = :OECDFlg
,SvrgnFlg = :SvrgnFlg
,PSEGovFlg = :PSEGovFlg
,NonPrftFlg = :NonPrftFlg
,SPEWCISFlg = :SPEWCISFlg
,FR2436RptInstnFlg = :FR2436RptInstnFlg
,FR2436CntrlCptyFlg = :FR2436CntrlCptyFlg
,FR2436RefEntyTypTxt = :FR2436RefEntyTypTxt
,FR2436EqtyCptyRgnTxt = :FR2436EqtyCptyRgnTxt
,FR2436CDSCptyRgnTxt = :FR2436CDSCptyRgnTxt
,HCLRCLCptyTypTxt = :HCLRCLCptyTypTxt
,CERCptyType1Txt = :CERCptyType1Txt
,CERCptyType2Txt = :CERCptyType2Txt
,SrcId = :SrcId
,CMRSCIIdTxt = :CMRSCIIdTxt
,SPECnsldPrntContrPartyTypTxt = :SPECnsldPrntContrPartyTypTxt
,CntryOfPrnclBsnsAddrId = :CntryOfPrnclBsnsAddrId
,CntryOfIncId = :CntryOfIncId
,VrsnComment = :VrsnComment
,SrcBsnsDt = :SrcBsnsDt
,UserNm = :UserNm
,UserMchnAddr = :UserMchnAddr
,UpdtTs = :UpdtTs
,CntryRiskClassNbr = :CntryRiskClassNbr

WHERE CustomerId = :CustomerId
