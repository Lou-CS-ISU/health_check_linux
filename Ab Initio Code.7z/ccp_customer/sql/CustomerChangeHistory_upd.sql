UPDATE HistSchema.CustomerChangeHistory
SET 
VrsnOrdrNbr                     = :VrsnOrdrNbr    
,SrcId                           = :SrcId          
,ModAtrbtNm                      = :ModAtrbtNm     
,ModAtrbtLabelNm                 = :ModAtrbtLabelNm
,OldVal                          = :OldVal         
,NewVal                          = :NewVal         
,Comment                         = :Comment        
,UserNm                          = :UserNm         
,UserMchnAddr                    = :UserMchnAddr   
,CrteTs                          = :CrteTs         
,UpdtTs                          = :UpdtTs         
WHERE 
CustomerId                      = :CustomerId
