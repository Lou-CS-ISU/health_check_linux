MERGE [dbo].[CustomerReportCategory] cra 
			USING CoRSINPUT_PRD.dbo.CustomerReportCategory crap
			ON cra.CustomerId = crap.CustomerId and cra.RptCtgryId=crap.RptCtgryId
			WHEN MATCHED THEN
			UPDATE SET 
          RptCtgryId =crap.RptCtgryId,
          SrcId =crap.SrcId,
          CrteUserNm =crap.CrteUserNm,
          CrteTs =crap.CrteTs,
          UserMchnAddr =crap.UserMchnAddr,
          UpdtUserNm =crap.UpdtUserNm,
          UpdtTs =crap.UpdtTs
			WHEN NOT MATCHED THEN
				INSERT (
				
    CustomerId,
    RptCtgryId,
    SrcId,
    CrteUserNm,
    CrteTs,
    UserMchnAddr,
    UpdtUserNm,
    UpdtTs
				
				)
				
				values
				
				(
				 CustomerId ,
    RptCtgryId,
     SrcId ,
    'etl_uat_CoRS_RW'
				,SYSDATETIME()
				,@@SERVERNAME
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
								);;;;