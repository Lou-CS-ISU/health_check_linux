
MERGE [dbo].[customer] c
			USING CoRSINPUT_PRD.dbo.customer cp
			ON   c.CustomerId =cp.CustomerId 
			WHEN MATCHED THEN
			UPDATE SET VrsnOrdrNbr =cp.VrsnOrdrNbr,
					   CustomerNm =cp.CustomerNm,
					   CustomerShortNm =cp.CustomerShortNm,
					   CustomerDesc =cp.CustomerDesc,
					   CustomerTypId =cp.CustomerTypId,
					   CustomerSubtypId =cp.CustomerSubtypId,
					   CntryDomicileId =cp.CntryDomicileId,
					   CntryCdId =cp.CntryCdId,
					   RegCntryOfDomicileId =cp.RegCntryOfDomicileId,
					   CntryOfHdqtrId =cp.CntryOfHdqtrId,
					   CntryOfRiskId =cp.CntryOfRiskId,
					   LglEntyIdTxt =cp.LglEntyIdTxt,
					   BranchFlg =cp.BranchFlg,
					   PtrtActCrtfyFlg =cp.PtrtActCrtfyFlg,
					   MgdAcctFlg =cp.MgdAcctFlg,
					   FnclInstnAssetOvr100BFlg =cp.FnclInstnAssetOvr100BFlg,
					   RegWCptyFlg =cp.RegWCptyFlg,
					   RegOCptyFlg =cp.RegOCptyFlg,
					   SICIndstCd =cp.SICIndstCd,
					   NAICSIndstCd =cp.NAICSIndstCd,
					   DunsNbrTxt =cp.DunsNbrTxt,
					   StckTicker =cp.StckTicker,
					   EntyTypDesc =cp.EntyTypDesc,
					   CityNm =cp.CityNm,
					   StNm =cp.StNm,
					   WebAddrTxt =cp.WebAddrTxt,
					   FXSpecNm =cp.FXSpecNm,
					   LglOrgDesc =cp.LglOrgDesc,
					   CustomerHierarchyOrdrNbr =cp.CustomerHierarchyOrdrNbr,
					   TaxIdNbr =cp.TaxIdNbr,
					   VrsnComment =cp.VrsnComment,
					   SrcBsnsDt =cp.SrcBsnsDt,
					   BranchLocId =cp.BranchLocId,
					   BsnsTypId =cp.BsnsTypId,
					   customerDescId =cp.customerDescId,
					   CrteUserNm =cp.CrteUserNm,
					   CrteTs =cp.CrteTs,
					   UserMchnAddr =cp.UserMchnAddr,
					   UpdtUserNm =cp.UpdtUserNm,
					   UpdtTs =cp.UpdtTs
			
			WHEN NOT MATCHED THEN
				INSERT 
				(
		
    CustomerId,
    VrsnOrdrNbr,
    CustomerNm,
    CustomerShortNm,
    CustomerDesc,
    CustomerTypId,
    CustomerSubtypId,
    CntryDomicileId,
    CntryCdId,
    RegCntryOfDomicileId,
    CntryOfHdqtrId,
    CntryOfRiskId,
    LglEntyIdTxt,
    BranchFlg,
    PtrtActCrtfyFlg,
    MgdAcctFlg,
    FnclInstnAssetOvr100BFlg,
    RegWCptyFlg,
    RegOCptyFlg,
    SICIndstCd,
    NAICSIndstCd,
    DunsNbrTxt,
    StckTicker,
    EntyTypDesc,
    CityNm,
    StNm,
    WebAddrTxt,
    FXSpecNm,
    LglOrgDesc,
    CustomerHierarchyOrdrNbr,
    TaxIdNbr,
    VrsnComment,
    SrcBsnsDt,
    BranchLocId,
    BsnsTypId,
    customerDescId,
    SrcId,
    CrteUserNm,
    CrteTs,
    UserMchnAddr,
    UpdtUserNm,
    UpdtTs

)
VALUES
(
   cp.CustomerId 
   ,cp.VrsnOrdrNbr
    ,cp.CustomerNm
    ,cp.CustomerShortNm 
    ,cp.CustomerDesc
   ,cp.CustomerTypId
   ,cp.CustomerSubtypId 
   ,cp.CntryDomicileId 
   ,cp.CntryCdId 
   ,cp.RegCntryOfDomicileId 
   ,cp.CntryOfHdqtrId
   ,cp.CntryOfRiskId
    ,cp.LglEntyIdTxt
   ,cp.BranchFlg
   ,cp.PtrtActCrtfyFlg
   ,cp.MgdAcctFlg
   ,cp.FnclInstnAssetOvr100BFlg
   ,cp.RegWCptyFlg
   ,cp.RegOCptyFlg
    ,cp.SICIndstCd
    ,cp.NAICSIndstCd
    ,cp.DunsNbrTxt
    ,cp.StckTicker
    ,cp.EntyTypDesc
    ,cp.CityNm
    ,cp.StNm
    ,cp.WebAddrTxt
    ,cp.FXSpecNm
    ,cp.LglOrgDesc
   ,cp.CustomerHierarchyOrdrNbr
    ,cp.TaxIdNbr
    ,cp.VrsnComment
    ,SrcBsnsDt
   ,cp.BranchLocId
   ,cp.BsnsTypId
   ,cp.customerDescId
   ,cp.SrcId
   ,'etl_uat_CoRS_RW', -- CrteUserNm - varchar
	SYSDATETIME(),
	@@SERVERNAME,
	'etl_uat_CoRS_RW',
	SYSDATETIME()
);;;;
				