MERGE [dbo].[Customerbase] cb
                        USING CoRSINPUT_PRD.dbo.Customerbase cbp
                        ON cb.CustomerId = cbp.CustomerId
                        WHEN MATCHED THEN
                        UPDATE SET
                                           cb.CoRSCustomerId = cbp.CoRSCustomerId
                                           

                        WHEN NOT MATCHED THEN
                                INSERT
                                (


                                                        CoRSCustomerId,
                                                        CustomerBaseTypId,
                                                        SrcId,
                                                        CrteUserNm,
                                                        CrteTs,
                                                        UserMchnAddr,
                                                        UpdtUserNm,
                                                        UpdtTs

                                                )
                                        VALUES
                                                (

                                                        cbp.CoRSCustomerId,
                                                        cbp.CustomerBaseTypId,
                                                        cbp.SrcId,
                                                        'etl_uat_CoRS_RW', -- CrteUserNm - varchar
                                                        SYSDATETIME(),
                                                        @@SERVERNAME,
                                                        'etl_uat_CoRS_RW',
                                                        SYSDATETIME()
                                                );;;;
