MERGE [dbo].[CustomerGroup] cg
			USING CoRSINPUT_PRD.dbo.CustomerGroup cgp
			ON cg.CustomerId = cgp.CustomerId and cg.GrpId=cgp.GrpId
			WHEN MATCHED THEN
			UPDATE SET 
			GrpId =cgp.GrpId,
			SrcId =cgp.SrcId,
			CrteUserNm =cgp.CrteUserNm,
			CrteTs =cgp.CrteTs,
			UserMchnAddr =cgp.UserMchnAddr,
			UpdtUserNm =cgp.UpdtUserNm,
			UpdtTs =cgp.UpdtTs
				
			
			WHEN NOT MATCHED THEN
				INSERT 
				(
				  CustomerId,
				    GrpId,
				    SrcId,
				    CrteUserNm,
				    CrteTs,
				    UserMchnAddr,
				    UpdtUserNm,
				    UpdtTs   	
				)
				VALUES
				(
				  CustomerId,
				GrpId,
				SrcId
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				,@@SERVERNAME
				,'etl_uat_CoRS_RW'
				,SYSDATETIME()
				);;;;


