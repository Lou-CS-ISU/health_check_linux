INSERT INTO CustomerBase
        (customerId
        ,vrsnOrdrNbr
        ,customerBaseTypId
        ,vldInd
        ,vrsnCmnt
        ,srcId
        ,recTs
        ,userNm
        ,userMchnId
        ,oprtnCd
        ,srcBsnsDt
        ,lastUpdtDt
        ,vrsnEfctDt
        )
VALUES (
        :customerId
        ,:vrsnOrdrNbr
        ,:customerBaseTypId
        ,:vldInd
        ,:vrsnCmnt
        ,:srcId
        ,:recTs
        ,:userNm
        ,:userMchnId
        ,:oprtnCd
        ,:srcBsnsDt
        ,:lastUpdtDt
        ,:vrsnEfctDt
        )

