SELECT * FROM dbo.crdStageCIDCustDetail WHERE businessDate=$business_date;
