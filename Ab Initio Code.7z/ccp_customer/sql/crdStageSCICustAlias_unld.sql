SELECT * FROM dbo.crdStageSCICustAlias WHERE businessDate=$business_date;
