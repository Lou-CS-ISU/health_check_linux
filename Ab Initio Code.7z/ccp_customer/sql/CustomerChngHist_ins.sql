INSERT INTO CustomerChngHist
        (customerId
        ,vrsnOrdrNbr
        ,modAtrbtNm
        ,prevValue
        ,newValue
        ,modBy
        ,modDt
        ,vldInd
        ,vrsnCmnt
        ,srcId
        ,recTs
        ,userNm
        ,userMchnId
        ,oprtnCd
        ,srcBsnsDt
        ,lastUpdtDt
        ,vrsnEfctDt

        )
VALUES (
        :customerId
        ,:vrsnOrdrNbr
        ,:modAtrbtNm
        ,:prevValue
        ,:newValue
        ,:modBy
        ,:modDt
        ,:vldInd
        ,:vrsnCmnt
        ,:srcId
        ,:recTs
        ,:userNm
        ,:userMchnId
        ,:oprtnCd
        ,:srcBsnsDt
        ,:lastUpdtDt
        ,:vrsnEfctDt

        )

