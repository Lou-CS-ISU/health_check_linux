SELECT * FROM dbo.crdStageSCICustHierarchy WHERE businessDate=$business_date;
