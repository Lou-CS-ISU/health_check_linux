UPDATE CustomerAlias
SET 
        customerId = :customerId
        ,aliasId = :aliasId
        ,prevCustomerId = :prevCustomerId
        ,sysCd = :sysCd
        ,bsnsAcctNm = :bsnsAcctNm
        ,creditSCI = :creditSCI
        ,tradeAdvncWICS = :tradeAdvncWICS
        --,vldInd = :vldInd
        --,vrsnCmnt = :vrsnCmnt
        ,srcId = :srcId
        ,recTs = :recTs
        ,userNm = :userNm
        ,userMchnId = :userMchnId
        ,oprtnCd = :oprtnCd
        ,srcBsnsDt = :srcBsnsDt
        ,lastUpdtDt = :lastUpdtDt
        ,vrsnEfctDt = :vrsnEfctDt

WHERE aliasId = :aliasId
