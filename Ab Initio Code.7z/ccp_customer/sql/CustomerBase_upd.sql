UPDATE CustomerBase
SET 
        CustomerBaseTypId = :CustomerBaseTypId
        ,UserNm = :UserNm
        ,UserMchnAddr = :UserMchnAddr
        ,UpdtTs = :UpdtTs
        ,SrcId = :SrcId

WHERE CustomerId = :CustomerId
