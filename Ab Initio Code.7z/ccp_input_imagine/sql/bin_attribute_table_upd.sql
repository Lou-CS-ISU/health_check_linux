UPDATE dbo.crdStageImagineBinAttribute
SET
        textFileLob = :textfilecontents
        ,binaryFileLob = :binfilecontents
WHERE holdingId = :holdingID and businessDate =:businessDate
