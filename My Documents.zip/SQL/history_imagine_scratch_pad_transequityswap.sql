INSERT INTO HistSchema.TransEquitySwap ("BsnsDt","TransactionEqtySwapId","VrsnTyp","VrsnNbr","SrcId","TransactionId","ChildTransactionId","DealId","AssetId","AssetTypId","ExctnId","NotionalCrncyId","HldngId","LnkId","DayCountTyp","TrueAssetTyp","BuySellInd","VldInd","DolrShftAmt","ErlyTermnSchedInd","ProductId","ProductSubTypId","SrcProductTypNm","SrcProductSubTypNm","CanTrmOnRstFlg","FairVolatilityMktFlg","IsBasketSwapFlg","IsTotRtrnFlg","IsAccrualFlg","DataExstFlg","FixdCpnRate","ModelNm","DeskNm","PrtflioNm","DvdndPrtctTxt","NotionalFixdOrVrblTxt","AvgLife","EfctDt","FrwrdDt","MaturityDt","ParVal","MtmAmt","OrgnlNotionalAmt","CurrNotionalAmt","TradeNotionalAmt","ContractNotionalAmt","NotionalInCrncyAmt","TradeNPVAmt","ContractNPVAmt","ContractSizeAmt","DeltaAmt","CoRsQtyAmt","QtyAmt","CurrEqtyRstAmt","VegaDollarsAmt","VegaDollarsInCrncyAmt","VolatilityStrikeAmt","CnvrtSpotAmt","FairVolatilityMktAmt","InitialValAmt","FxRateAmt","InitialMrgnAmt","InitialEqtyRstAmt","IntRateAmt","HistVolatilityAmt","StrikePrice","BasketPrice","DeliveryPrice","FrwrdPrice","RdmpnVal","VrncStrikeAmt","MPEVol","NbrOfSharesAmt","MrgnPct","VolatilityPct","ProductData1","ProductData2","UndlyCusipId","UndlyCrncyId","UndlyISINId","UndlyMktSymbolId","UndlySmId","UndlyNm","UndlySecTyp","UndlySymbolNm","UndlyIndstIndx","UndlySctrIndx","UndlyPrice","UndlySpotPrice","UndlySpotRateAmt","NotionalOrSharesAmt","CashStldFlg","CrteUserNm","CrteTs","UserMchnAddr","UpdtUserNm","UpdtTs") 
SELECT  '2017-09-12',TransactionEqtySwapId,'S',0,(select SrcId from dbo.SrcSys where SrcSys.SrcFileTagNm = 'IMAGINE_TRANS' and SrcTypCd ='F'), TransactionId,ChildTransactionId,DealId,AssetId,AssetTypId,ExctnId,NotionalCrncyId,HldngId,LnkId,DayCountTyp,TrueAssetTyp,BuySellInd,VldInd,DolrShftAmt,ErlyTermnSchedInd,ProductId,ProductSubTypId,SrcProductTypNm,SrcProductSubTypNm,CanTrmOnRstFlg,FairVolatilityMktFlg,IsBasketSwapFlg,IsTotRtrnFlg,IsAccrualFlg,DataExstFlg,FixdCpnRate,ModelNm,DeskNm,PrtflioNm,DvdndPrtctTxt,NotionalFixdOrVrblTxt,AvgLife,EfctDt,FrwrdDt,MaturityDt,ParVal,MtmAmt,OrgnlNotionalAmt,CurrNotionalAmt,TradeNotionalAmt,ContractNotionalAmt,NotionalInCrncyAmt,TradeNPVAmt,ContractNPVAmt,ContractSizeAmt,DeltaAmt,CoRsQtyAmt,QtyAmt,CurrEqtyRstAmt,VegaDollarsAmt,VegaDollarsInCrncyAmt,VolatilityStrikeAmt,CnvrtSpotAmt,FairVolatilityMktAmt,InitialValAmt,FxRateAmt,InitialMrgnAmt,InitialEqtyRstAmt,IntRateAmt,HistVolatilityAmt,StrikePrice,BasketPrice,DeliveryPrice,FrwrdPrice,RdmpnVal,VrncStrikeAmt,MPEVol,NbrOfSharesAmt,MrgnPct,VolatilityPct,ProductData1,ProductData2,UndlyCusipId,UndlyCrncyId,UndlyISINId,UndlyMktSymbolId,UndlySmId,UndlyNm,UndlySecTyp,UndlySymbolNm,UndlyIndstIndx,UndlySctrIndx,UndlyPrice,UndlySpotPrice,UndlySpotRateAmt,NotionalOrSharesAmt,CashStldFlg,CrteUserNm,CrteTs,UserMchnAddr,UpdtUserNm,UpdtTs 
FROM dbo.TransEquitySwap WHERE TransactionEqtySwapId NOT IN (SELECT t.TransactionEqtySwapId 
							     FROM dbo.TransEquitySwap t WHERE t.TransactionId = '-99999999' AND t.ChildTransactionId = 'ZZZZZZZZZZ' AND t.DealId = 'ZZZZZZZZZZ');

DELETE FROM HistSchema.Transequityswap
WHERE BsnsDt = '2017-09-12'


SELECT COUNT(*) FROM dbo.Transequityswap

SELECT t.TransactionEqtySwapId, t.TransactionId, t.ChildTransactionId
FROM dbo.Transequityswap t

SELECT COUNT(*) FROM HistSchema.Transequityswap
WHERE BsnsDt = '2017-09-12'

DELETE FROM HistSchema.Transequityswap
WHERE BsnsDt = '2017-09-12'

select * from dbo.TransEquitySwap where TransactionId in 
(select TransactionId from dbo.Trans
 Where SrcId in ( select SrcId 
                 from dbo.SrcSys where SrcFileTagNm in ('IMAGINE_TRANS')))
and updtTs > '2017-09-08 10:24:12'
and updtUserNm not like 'ccp%'

