
SELECT max(t.VrsnNbr) as VrsnNbr ,t.TransactionId 
FROM HistSchema.Trans t 
WHERE  t.BsnsDt='20170725' 
and transactionid = 29713 



select TransactionId from dbo.Trans 
Where SrcId in ( select SrcId
                 from dbo.SrcSys where SrcFileTagNm in ('IMAGINE_TRANS'))
and updtTs > '2017-08-25 04:08:21' 
and updtUserNm not like 'ccpetl%'

CoRSTransactionId
IMA_216773

SELECT t.TransactionId, t.*
FROM HistSchema.Trans t 
WHERE  t.TransactionId = '1711518'
GROUP BY t.TransactionId

select * from HistSchema.TransEquitySwap
select * from [CoRSINPUT_UAT2].[dbo].[TransEquityPFECashDvdndSched]

select * from [CoRSINPUT_UAT2].[Histschema].[TransEquityPFECashDvdndSched]


select * from [CoRSCONFIG_UAT2].[dbo].[ETLHistoryConfiguration] where TblNm like 'TransEquityPFECashDvdndSched'