select count(*) from histschema.customerportal
where vrsntyp = 'S'
and HistCrtets > '20171002'			0		0

select count(*) from histschema.Trans
where vrsntyp = 'S'
and HistCrtets > '20171002'			175380  290334



											select count(*) from histschema.TransFacilityGrade
											where vrsntyp = 'S'
											and HistCrtets > '20171002'			0					0   OK

select count(*) from histschema.TransLoanGuarantor
where vrsntyp = 'S'
and HistCrtets > '20171002'			0					58

select count(*) from histschema.TransLoanLending
where vrsntyp = 'S'
and HistCrtets > '20171002'			0					114954

													select count(*) from histschema.TransLoanMoneyMarket
													where vrsntyp = 'S'
													and HistCrtets > '20171002'			37				37		OK

													select count(*) from histschema.TransLoanRiskCustomer
													where vrsntyp = 'S'
													and HistCrtets > '20171002'			0				0

select count(*) from histschema.TransLoanRiskSchedule
where vrsntyp = 'S'
and HistCrtets > '20171002'			0				294

select count(*) from histschema.TransPortal
where vrsntyp = 'S'
and HistCrtets > '20171002'			6957			58359


SELECT  '20170725',TransactionFacilityGrdId,'S',0,SrcId, BQRSbstnRsnId,TransactionId,RatingTypId,RatingCd,RatingEfctDt,PriorityCd,RatingAmt,RatingPct,AsgnrId,CoRSSrcId,CrteUserNm,CrteTs,UserMchnAddr,UpdtUserNm,UpdtTs 
FROM dbo.TransFacilityGrade WHERE TransactionFacilityGrdId NOT IN (SELECT t.TransactionFacilityGrdId FROM dbo.TransFacilityGrade t WHERE t.TransactionId = '-99999999') 
AND SrcId in ( select SrcId from dbo.SrcSys where SrcFileTagNm in ('AFSBANK01_TRANS'))

SELECT  '20170725',TransactionId,'S',0,(select SrcId from dbo.SrcSys where SrcSys.SrcFileTagNm = 'AFSBANK01_TRANS' and SrcTypCd = 'F'), Rate,RateIndxCd,SpotPrice,RateSprdAmt,ExpsrValInCrncyAmt,ExpsrValInUSDAmt,EfctDt,ParAmt,MktPriceAmt,LongShortId,ExpsrCrncyId,AssetId,ProcessTyp,MstrExpsrOblgrId,MstrExpsrOblgnId,ExpsrInd,TopInd,MidlInd,BtmInd,IncldIndFlg,PrnclBalCurrAmt,CoBalAmt,TotPrtcpAmt,IntPaidToPrnclAmt,BookBalAmt,SpclProductCd,DscntCd,CptyTyp,AdvisedGdncId,OblgrId,OblgnId,DirOblgrCptyTyp,LongTermId,NetActvyAmt,BookActvyAmt,NetBookBalAmt,NewExstgInd,CrteUserNm,CrteTs,UserMchnAddr,UpdtUserNm,UpdtTs 
FROM dbo.TransLoanMoneyMarket WHERE TransactionId NOT IN (SELECT t.TransactionId FROM dbo.TransLoanMoneyMarket t WHERE t.TransactionId = '-99999999') 
AND TransactionId in (select TransactionId from dbo.Trans Where SrcId in ( select SrcId from dbo.SrcSys where SrcFileTagNm in ('AFSBANK01_TRANS')))

SELECT  '20170725',CustomerId,TransactionId,'S',0,(select SrcId from dbo.SrcSys where SrcSys.SrcFileTagNm = 'AFSBANK01_TRANS' and SrcTypCd = 'F'), CustomerNm,RiskMtgntPct,RiskMtgntTypId,StatCd,CrteUserNm,CrteTs,UserMchnAddr,UpdtUserNm,UpdtTs 
FROM dbo.TransLoanRiskCustomer WHERE CustomerId NOT IN (SELECT t.CustomerId FROM dbo.TransLoanRiskCustomer t WHERE t.TransactionId = '-99999999') 
AND TransactionId in (select TransactionId from dbo.Trans Where SrcId in ( select SrcId from dbo.SrcSys where SrcFileTagNm in ('AFSBANK01_TRANS')))
