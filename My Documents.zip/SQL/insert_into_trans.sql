USE [CoRSINPUT]
GO

INSERT INTO [dbo].[Trans]
           ([CoRSTransactionId]
           ,[BookingCustomerId]
           ,[LglCustomerId]
           ,[BookingLglEntyId]
           ,[LglEntyId]
           ,[TradeStatId]
           ,[StlmtTypId]
           ,[MrkCrncyId]
           ,[StlmtCrncyId]
           ,[ProductId]
           ,[ProductSubTypId]
           ,[CntryOfRiskId]
           ,[ProcessStatId]
           ,[AU]
           ,[BookOrInventory]
           ,[GLAcctId]
           ,[GLSubAcctNbr]
           ,[GLEnty]
           ,[TaxId]
           ,[NotionalAmt]
           ,[MtmAmt]
           ,[MrkInCrncyAmt]
           ,[UpfrntColtralAmt]
           ,[InitialMrgnPct]
           ,[MrkCalcDt]
           ,[TradeDt]
           ,[DeliveryDt]
           ,[MaturityDt]
           ,[EfctDt]
           ,[EndDt]
           ,[SrcBsnsDt]
           ,[AmendmentDt]
           ,[CDCUpdtDt]
           ,[InternalFlg]
           ,[IsBookingCustomerABranchFlg]
           ,[IsBookingWLEABranchFlg]
           ,[TrmOpenIndFlg]
           ,[AmendedTdyFlg]
           ,[MuniFlg]
           ,[CRMFlg]
           ,[DCoEFlg]
           ,[BaselFlg]
           ,[CVAFlg]
           ,[PFEFlg]
           ,[CntryOfRiskOvrdFlg]
           ,[IsMnlTradeFlg]
           ,[IsTradeFromTdyFlg]
           ,[VldTradeFlg]
           ,[TradeComment]
           ,[TradeDesc]
           ,[CCRMFltrRuleFrcRjctTxt]
           ,[DelrFlgTxt]
           ,[SysCd]
           ,[SrcSysNm]
           ,[SrcClntId]
           ,[SrcClntNm]
           ,[SrcProductTyp]
           ,[SrcProductSubTyp]
           ,[SrcTradeId]
           ,[SrcTradeIdAlias]
           ,[TrlChckStatFlg]
           ,[SignificantlyModFlg]
           ,[BifurcatedIsncIndFlg]
           ,[SrcId]
           ,[CrteUserNm]
           ,[CrteTs]
           ,[UserMchnAddr]
           ,[UpdtUserNm]
           ,[UpdtTs])
     VALUES
           ('IMA_LOUTEST'
           ,8939
           ,8939
           ,60
           ,60
           ,5146
           ,NULL
           ,146
           ,NULL
           ,4063
           ,NULL
           ,NULL
           ,NULL
           ,0102042   
           ,'N.SDIDX.WBNA'
           ,NULL
           ,NULL
           ,0000
           ,NULL
           ,3999999.9872250000
           ,-4352.65510456712
           ,-4352.65510456712
           ,0.0000000000
           ,NULL
           ,'2017-07-25 00:00:00.000'
           ,'2008-10-06 00:00:00.000'
           ,NULL
           ,'2018-10-08 00:00:00.000'
           ,'2008-10-06 00:00:00.000'
           ,'2018-10-08 00:00:00.000'
           ,'2017-07-25 00:00:00.000'
           ,NULL
           ,NULL
           ,0
           ,0
           ,0
           ,NULL
           ,0
           ,NULL
           ,1
           ,1
           ,1
           ,1
           ,0
           ,NULL
           ,0
           ,0
           ,NULL
           ,'K: 1214 C4789 O: 2779'
           ,'o.SPX181008P-2 OTC USD IDX.WBNA GG'
           ,NULL
           ,NULL
           ,'IMAGIN'
           ,'IMAGINE'
           ,8622
           ,'UNION HAMILTON REINSURANCE LTD'
           ,'OTC'
           ,'Option'
           ,248269
           ,NULL
           ,NULL
           ,0
           ,0
           ,106
           ,'u496456'
           ,'2017-08-29 01:20:52.887'
           ,'laptop'
           ,'u496456'
           ,'2017-08-29 01:22:52.887')
GO


