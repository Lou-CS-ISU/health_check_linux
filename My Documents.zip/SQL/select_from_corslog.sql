select * from CorsLog..CoRSLog where logid like 'LoanN%'
order by LogId 

select * from CorsLog..CoRSLog where logid like '%GMI%OTC%'
order by LogId 


update CoRsLog..CoRsLog set JobStat='' where LogId  like 'LoanN%'

update CoRsLog..CoRsLog set JobStat='Success' where LogId  like 'LoanN%'

update CoRsLog..CoRsLog set JobStat='Running' where LogId  like 'LoanN%'


update CoRsLog..CoRsLog set JobEndTm='2017-06-19 05:24:19.947' where LogId = 'LoanNet_BorrowLend.5'

delete from CorsLog..CoRSLog where LogId = 'LoanNet_BorrowLend.6'

--delete from CoRsLog..CoRsLOg where LogId like 'Asset_ProductDetail.2' 
delete from CoRsLog..CoRsLOgDetail where LogId like 'Asset_ProductDetail.2'


select * from HistSchema.TransChangeHistory
where CrteUserNm = 'u496456'
or UpdtUserNm = 'u496456'