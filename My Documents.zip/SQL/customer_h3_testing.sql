------------------------------------------------------------------------------------
CUSTOMER
------------------------------------------------------------------------------------

select count(*) from dbo.CountryCodeWICS

select count(*) from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'


select * from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerBase				4289331

select count(*) from HistSchema.CustomerBase		4289331
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerBase
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerBase
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerAlias						32595658

select count(*) from HistSchema.CustomerAlias
where BsnsDt='2017-07-26'
and vrsntyp = 'S'

select count(*) from dbo.CustomerAlias

select* from HistSchema.CustomerAlias
where BsnsDt='2017-07-26'
and vrsntyp = 'S'
and HistCrteTs < '20171003 13:50:00'
and VrsnNbr = 0 

delete from HistSchema.CustomerAlias
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerAdditionalAttribute			4283800

select count(*) from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.Customer					4289332

select count(*) from HistSchema.Customer			4289332
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.Customer
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.Customer
where BsnsDt='2017-07-25'
and vrsntyp = 'S'


------------------------------------------------------------------------------------

select count(*) from dbo.CustomerHierarchy					173469

select count(*) from HistSchema.CustomerHierarchy			173469
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerHierarchy
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerHierarchy
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerPortal				193946

select count(*) from HistSchema.CustomerPortal		193959
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerPortal
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerPortal
where BsnsDt='2017-07-25'
and vrsntyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.CustomerRating				4289328

select count(*) from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

with MyMax as (SELECT max(t.VrsnNbr) + 1 as MaxVrsnNbr, t.CustomerId,t.BsnsDt FROM HistSchema.customeralias t WHERE t.BsnsDt='20170726' GROUP BY t.CustomerId,t.BsnsDt) 
UPDATE HistSchema.customeralias SET VrsnNbr = m.MaxVrsnNbr 
FROM HistSchema.customeralias h join MyMax m on h.CustomerId= m.CustomerId and h.BsnsDt= m.BsnsDt WHERE  h.BsnsDt='20170726' 
AND h.VrsnNbr = 0;

SELECT max(t.VrsnNbr) + 1 as MaxVrsnNbr, t.CustomerId,t.BsnsDt FROM HistSchema.customeralias t WHERE t.BsnsDt='20170726' GROUP BY t.CustomerId,t.BsnsDt

SELECT max(t.VrsnNbr) + 1 as MaxVrsnNbr, t.CustomerId,t.BsnsDt FROM HistSchema.customeralias t WHERE t.BsnsDt='20170726' AND t.VrsnNbr <> 0 and vrsntyp = 'S' GROUP BY t.CustomerId,t.BsnsDt

delete from HistSchema.Trans
where VrsnNbr = 0 

delete from  HistSchema.TransEquitySAMIVolatility
where HistCrteTS > '20171003 20:00:00'
and vrsnNbr <> 0

where_clause
with MyMax as (SELECT max(t.VrsnNbr) + 1 as MaxVrsnNbr, t.TransactionSAMIVolatilityId FROM HistSchema.transequitysamivolatility t WHERE t.BsnsDt='20170725' GROUP BY t.TransactionSAMIVolatilityId) 
UPDATE HistSchema.transequitysamivolatility SET VrsnNbr = m.MaxVrsnNbr FROM HistSchema.transequitysamivolatility h join MyMax m on h.TransactionSAMIVolatilityId= m.TransactionSAMIVolatilityId 
WHERE  h.BsnsDt='20170725' 
AND h.VrsnNbr = 0
