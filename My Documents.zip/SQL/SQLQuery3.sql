------------------------------------------------------------------------------------
CUSTOMER
------------------------------------------------------------------------------------

select count(*) from dbo.CountryCodeWICS

select count(*) from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'


select * from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerBase				4289331

select count(*) from HistSchema.CustomerBase		4289331
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerBase
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerBase
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerAlias						32595658

select count(*) from HistSchema.CustomerAlias
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select count(*) from dbo.CustomerAlias

select * from HistSchema.CustomerAlias
where BsnsDt='2017-07-25'
and vrsntyp = 'S'
and HistCrteTs > '20171003'

delete from HistSchema.CustomerAlias
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerAdditionalAttribute			4283800

select count(*) from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.Customer					4289332

select count(*) from HistSchema.Customer			4289332
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.Customer
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.Customer
where BsnsDt='2017-07-25'
and vrsntyp = 'S'


------------------------------------------------------------------------------------

select count(*) from dbo.CustomerHierarchy					173469

select count(*) from HistSchema.CustomerHierarchy			173469
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerHierarchy
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerHierarchy
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerPortal				193946

select count(*) from HistSchema.CustomerPortal		193959
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerPortal
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerPortal
where BsnsDt='2017-07-25'
and vrsntyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.CustomerRating				4289328

select count(*) from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'
