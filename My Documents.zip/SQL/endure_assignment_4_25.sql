select * from crdrs.crdBusinessDays  --backoff trans id, business date, and transaction id should match

--2017-03-28 00:00:00.000	current
--2017-03-27 00:00:00.000	previous
--2017-03-29 00:00:00.000	next 

select * from crdrs.dbo.crdStageEndurTerminationDates

delete from crdrs.dbo.crdStageEndurTerminationDates
where backOfficeTransId = 1522364

select * from crdrs.dbo.crdStageEndurTransactions where businessDate = '2017/03/28'

select * from dbo.TransEarlyTermination TC 
 inner join dbo.Trans on TC.TransactionId = Trans.TransactionId 
 inner join dbo.SrcSys on TC.SrcId = SrcSys.SrcId and SrcSys.SrcFileTagNm='ENDUR_TRANS' 

 select * from dbo.TransEarlyTermination
 order by CrteTs asc

select * from dbo.trans t, dbo.SrcSys s
    where t.SrcId = s.SrcId
	and s.SrcFileTagNm='ENDUR_TRANS' 

select * from GnrcClass where GnrcClassNm like 'EarlyTermination Type'
