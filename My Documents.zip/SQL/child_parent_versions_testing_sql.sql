select * from HistSchema.Trans
where BsnsDt = '2017-07-25'
and VrsnTyp = 'S'

select * from HistSchema.transownerroleassoc
where BsnsDt = '2017-07-25'
and VrsnTyp = 'S'

delete from HistSchema.Trans
where BsnsDt = '2017-07-25'
and VrsnTyp = 'S'

delete from HistSchema.transequityoption
where BsnsDt = '2017-07-25'
and VrsnTyp = 'S'

--------------------------------------------------------------------

select c.* from dbo.transownerroleassoc c, dbo.trans p 
where c.transactionid = p.transactionid
AND p.SrcId in ( select SrcId from dbo.SrcSys where SrcFileTagNm in ('IMAGINE_TRANS'))

select count(*) from dbo.trans where transactionid = 1896792

select VrsnNbr, * from histschema.trans where transactionid = 1896792 and BsnsDt = '2017-07-25'

select count(*) from dbo.transownerroleassoc where transactionid = 1896792

select VrsnNbr, * from histschema.transownerroleassoc where transactionid = 1896792 and BsnsDt = '2017-07-25'

-----------------------------------------------------------------------------------------------------------------------------------

SELECT * 
FROM HistSchema.transequitybasketcomponent h join HistSchema.transequityoption l on h.TransactionEqtyOptnPrntId = l.TransactionEqtyOptnId
WHERE  h.BsnsDt='20170726' 

SELECT * 
FROM HistSchema.transequitybasketcomponent h join HistSchema.TransEquitySwap l on h.TransactionEqtyPrntId = l.TransactionEqtySwapId
WHERE  h.BsnsDt='20170726' 

