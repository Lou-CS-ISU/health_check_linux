select * from etlhistoryconfiguration where loadind='Y'
and SORNm like '%Imagine%'

select count(*) from HistSchema.Trans
where BsnsDt='2017-09-12'

delete from HistSchema.Trans
where BsnsDt= '2017-09-12'

INSERT INTO HistSchema.Trans ("BsnsDt","TransactionId","VrsnTyp","VrsnNbr","SrcId","CoRSTransactionId","BookingCustomerId","LglCustomerId","BookingLglEntyId","LglEntyId","TradeStatId","MrkCrncyId","StlmtTypId","StlmtCrncyId","ProcessStatId","ProductId","AU","BookOrInventory","GLAcctId","GLSubAcctNbr","GLEnty","NotionalAmt","MtmAmt","DeliveryDt","MaturityDt","IsBookingCustomerABranchFlg","IsBookingWLEABranchFlg","IsMnlTradeFlg","InternalFlg","TrmOpenIndFlg","CRMFlg","DCoEFlg","BaselFlg","CVAFlg","MrkInCrncyAmt","MrkCalcDt","SrcBsnsDt","SrcSysNm","SysCd","SrcClntId","SrcClntNm","SrcProductTyp","SrcProductSubTyp","SrcTradeId","SrcTradeIdAlias","IsTradeFromTdyFlg","TradeDt","TradeComment","EfctDt","TradeDesc","UpfrntColtralAmt","EndDt","CCRMFltrRuleFrcRjctTxt","CDCUpdtDt","CntryOfRiskOvrdFlg","CntryOfRiskId","ProductSubTypId","TaxId","MuniFlg","AmendmentDt","VldTradeFlg","InitialMrgnPct","DelrFlgTxt","AmendedTdyFlg","PFEFlg","TrlChckStatFlg","SignificantlyModFlg","BifurcatedIsncIndFlg","CrteUserNm","CrteTs","UserMchnAddr","UpdtUserNm","UpdtTs") 
SELECT  '2017-09-12',TransactionId,'S',0,(select SrcId from dbo.SrcSys where SrcSys.SrcFileTagNm = 'IMAGINE_TRANS' and SrcTypCd ='F'), CoRSTransactionId,BookingCustomerId,LglCustomerId,BookingLglEntyId,LglEntyId,TradeStatId,MrkCrncyId,StlmtTypId,StlmtCrncyId,ProcessStatId,ProductId,AU,BookOrInventory,GLAcctId,GLSubAcctNbr,GLEnty,NotionalAmt,MtmAmt,DeliveryDt,MaturityDt,IsBookingCustomerABranchFlg,IsBookingWLEABranchFlg,IsMnlTradeFlg,InternalFlg,TrmOpenIndFlg,CRMFlg,DCoEFlg,BaselFlg,CVAFlg,MrkInCrncyAmt,MrkCalcDt,SrcBsnsDt,SrcSysNm,SysCd,SrcClntId,SrcClntNm,SrcProductTyp,SrcProductSubTyp,SrcTradeId,SrcTradeIdAlias,IsTradeFromTdyFlg,TradeDt,TradeComment,EfctDt,TradeDesc,UpfrntColtralAmt,EndDt,CCRMFltrRuleFrcRjctTxt,CDCUpdtDt,CntryOfRiskOvrdFlg,CntryOfRiskId,ProductSubTypId,TaxId,MuniFlg,AmendmentDt,VldTradeFlg,InitialMrgnPct,DelrFlgTxt,AmendedTdyFlg,PFEFlg,TrlChckStatFlg,SignificantlyModFlg,BifurcatedIsncIndFlg,CrteUserNm,CrteTs,UserMchnAddr,UpdtUserNm,UpdtTs 
FROM dbo.Trans 
WHERE TransactionId NOT IN (SELECT t.TransactionId FROM dbo.Trans t WHERE t.CoRSTransactionId = 'OTC111222-8989971_WCM') 
AND TransactionId NOT IN (SELECT t.TransactionId FROM dbo.Trans t WHERE t.CoRSTransactionId = 'ZZZZZZZZZZ');


;with MyMax as
(
SELECT max(t.VrsnNbr) + 1 as MaxVrsnNbr, t.TransactionId 
				FROM HistSchema.Trans t
				WHERE  t.BsnsDt='2017-09-12'
				GROUP BY t.TransactionId
)
update HistSchema.Trans
SET VrsnNbr = m.MaxVrsnNbr
From HistSchema.Trans h join MyMax m on h.TransactionId = m.TransactionId
WHERE  h.BsnsDt='2017-09-12'
AND h.VrsnNbr = 0

select count(*) from dbo.Trans