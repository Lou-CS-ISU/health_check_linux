USE [crdrs]
GO

INSERT INTO [dbo].[crdStageEndurTerminationDates]
           ([businessDate]
           ,[repository]
           ,[backOfficeTransId]
           ,[mandatoryFlag]
           ,[earlyTerminationType]
           ,[earlyTerminationDate])
     VALUES
           ('2017/03/28 00:00:00.000',
           'END_1941738', 
           '1757061',
           'Y', 
           'Other',
           '2017/01/11 00:00:00.000')
GO

---2017-03-28 00:00:00.000END_1143107 1522364 Y Other 2017-01-11 00:00:00.000
---2017-03-28 00:00:00.000END_1514917 1751214 Y Other 2017-01-11 00:00:00.000
---2017-03-28 00:00:00.000END_1941738 1757061 Y Other 2017-01-11 00:00:00.000

delete from crdrs.dbo.crdStageEndurTerminationDates
