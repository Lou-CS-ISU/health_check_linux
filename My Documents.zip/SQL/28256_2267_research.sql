select * from TransSecRepoLendingCash where TransactionId in (716339,716534,709930)

select * from corslog..BusinessException where ETLIssueCd='CCP_ERR_CASHNOTIONALINCRNCYAMT'  

select * from corslog..ExceptionEvent where BsnsExcpnId=100

select * from corslog..corslog where logid like '%loannet%'

select collateralCurrencyCode,cashAmountEod, * from crdrs..crdStageLoanNetTransactions where businessDate='2017-03-28 00:00:00.000'
 and transactionId in ('LOA_374660168_2480_B','LOA_370876551_2480_B','LOA_370835085_2480_B')

 --- Target 

 select CashNotionalInCrncyAmt,CashNotionalInUSDAmt, * from TransSecRepoLendingCash where TransactionId in (716339,716534,709930)
 
 select CRMFlg,CCRMFltrRuleFrcRjctTxt,ProcessStatId, * from trans where TransactionId in (716339,716534,709930)

 select SpotRate,* from FXRate where FromCrncyId= (select crncyid from currency where CrncyISOCd= 'USD') and ToCrncyId=(select crncyid from currency where CrncyISOCd= 'USD')
