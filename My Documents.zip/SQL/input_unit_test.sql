USE [CoRSINPUT]
GO

INSERT INTO [dbo].[TransOwnerRoleAssoc]
           ([TransactionId]
           ,[OwnerRoleTypId]
           ,[OwnerNm]
           ,[OwnerId]
           ,[CrteUserNm]
           ,[CrteTs]
           ,[UserMchnAddr]
           ,[UpdtUserNm]
           ,[UpdtTs])
     VALUES
           (1896792
           ,5246
           ,'IS_TRADING'
           ,NULL
           ,'u502545'
           ,'2017-09-07 04:59:08.443'
           ,'cdpra04a0400'
           ,'u423579'
           ,'2017-09-24 11:52:56.333')
GO

delete from [dbo].[TransOwnerRoleAssoc] where transactionid = 1896792

