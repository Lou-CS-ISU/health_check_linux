delete from corslog..corslog where logid='IMAGINE_EQUITY_HIST_LOAD.10'


select count(*) from Histschema.AssetCallPutSchedule
where BsnsDt='2017-07-25' and VrsnTyp = 'S'

select count(*) from Histschema.AssetCouponSchedule
where BsnsDt='2017-07-25' and VrsnTyp = 'S'

	delete from Histschema.AssetCouponSchedule
	where BsnsDt='2017-07-25' and VrsnTyp = 'S'

select count(*) from Histschema.AssetFloatInfo
where BsnsDt='2017-07-25' and VrsnTyp = 'S'

	delete from Histschema.AssetFloatInfo
	where BsnsDt='2017-07-25' and VrsnTyp = 'S'

select count(*) from Histschema.Asset
where BsnsDt='2017-07-25' and VrsnTyp = 'S'

select count(*) from Histschema.AssetPriceHistory
where BsnsDt='2017-07-25' and VrsnTyp = 'S'

	delete from Histschema.AssetPriceHistory
	where BsnsDt='2017-07-25' and VrsnTyp = 'S'

select count(*) from Histschema.AssetRating
where BsnsDt='2017-07-25' and VrsnTyp = 'S'

	delete from Histschema.AssetRating
	where BsnsDt='2017-07-25' and VrsnTyp = 'S'

select count(*) from Histschema.AssetSinkSchedule
where BsnsDt='2017-07-25' and VrsnTyp = 'S'