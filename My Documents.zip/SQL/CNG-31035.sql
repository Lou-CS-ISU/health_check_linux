Update CoRSCONFIG..ETLHistoryConfiguration
Set LoadInd = 'N' where  tblnm like '%CollateralDet%'