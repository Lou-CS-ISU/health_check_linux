USE [CoRSINPUT]
GO

UPDATE [dbo].[Trans]
   SET [UpdtTs] = '2017-08-29 05:22:52.887'
 WHERE [TransactionId] = 1777827
GO


