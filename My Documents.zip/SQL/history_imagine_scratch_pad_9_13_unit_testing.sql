delete from corslog..corslog where logid='IMAGINE_EQUITY_HIST_LOAD.10'

select count(*) from dbo.Trans

	select count(*) from HistSchema.Trans
	where BsnsDt='2017-07-26'
	and VrsnTyp = 'S'

select * from HistSchema.Trans
where BsnsDt='2017-07-26'

delete from HistSchema.Trans
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.TransEquity

select * from HistSchema.TransEquity
where BsnsDt='2017-07-26'

	select count(*) from HistSchema.TransEquity
	where BsnsDt='2017-07-26'
	and VrsnTyp = 'S'

delete from HistSchema.TransEquity
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.TransEquityBasketComponent

	select count(*) from HistSchema.TransEquityBasketComponent
	where BsnsDt='2017-07-25'
	and VrsnTyp = 'S'

select count(*) from HistSchema.TransEquityBasketComponent
where BsnsDt='2017-07-25' and VrsnTyp = 'S'
and HistCrteTs > '20170927'
and VrsnNbr = 0

select count(*) from HistSchema.TransEquityBasketComponent
where BsnsDt='2017-07-25'
and VrsnTyp = 'S'
and HistCrteTs > '20170927'
and VrsnNbr = 1

delete from HistSchema.TransEquityBasketComponent
where BsnsDt='2017-07-25'
and VrsnTyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.TransEquityOption

	select count(*) from HistSchema.TransEquityOption
	where BsnsDt='2017-07-26'
		and VrsnTyp = 'S'

select * from HistSchema.TransEquityOption
where HistCrteTs > '20170928'

delete from HistSchema.TransEquityOption
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.TransEquitySAMIVolatility

	select count(*) from HistSchema.TransEquitySAMIVolatility
	where BsnsDt='2017-07-26'
		and VrsnTyp = 'S'

select * from HistSchema.TransEquitySAMIVolatility
where BsnsDt='2017-07-26'

delete from HistSchema.TransEquitySAMIVolatility
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.TransEquitySwap

	select count(*) from HistSchema.TransEquitySwap
	where BsnsDt='2017-07-26'
	and VrsnTyp = 'S'

select * from HistSchema.TransEquitySwap
where BsnsDt='2017-07-26'

delete from HistSchema.TransEquitySwap
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.TransEquitySwapExtension

												select count(*) from HistSchema.TransEquitySwapExtension
												where BsnsDt='2017-07-26'
												and VrsnTyp = 'S'

select * from HistSchema.TransEquitySwapExtension
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'

delete from HistSchema.TransEquitySwapExtension
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.TransIR

	select count(*) from HistSchema.TransIR
	where BsnsDt='2017-07-26'
	and VrsnTyp = 'S'

select * from HistSchema.TransIR
where BsnsDt='2017-07-26'

delete from HistSchema.TransIR
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.TRANSIRLEG

	select count(*) from HistSchema.TRANSIRLEG
	where BsnsDt='2017-07-26'
	and VrsnTyp = 'S'

select * from HistSchema.TRANSIRLEG
where BsnsDt='2017-07-26'

delete from HistSchema.TransEquity
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'

-----------------------------------------------------------------------------------

select count(*) from dbo.TRANSOWNERROLEASSOC

	select count(*) from HistSchema.TRANSOWNERROLEASSOC
	where BsnsDt='2017-07-26'
	and VrsnTyp = 'S'

select * from HistSchema.TRANSOWNERROLEASSOC
where BsnsDt='2017-07-26'

delete from HistSchema.TRANSOWNERROLEASSOC
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.TRANSPORTAL

	select count(*) from HistSchema.TRANSPORTAL
	where BsnsDt='2017-07-26'
	and VrsnTyp = 'S'

select * from HistSchema.TRANSPORTAL
where BsnsDt='2017-07-26'

delete from HistSchema.TRANSPORTAL
where BsnsDt='2017-07-26'
and VrsnTyp = 'S'

------------------------------------------------------------------------------------
CUSTOMER
------------------------------------------------------------------------------------

select count(*) from dbo.CountryCodeWICS

select count(*) from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CountryCodeWICS
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.Customer

select count(*) from HistSchema.Customer
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.Customer
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.Customer
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerAdditionalAttribute

select count(*) from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerAdditionalAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'


------------------------------------------------------------------------------------

select count(*) from dbo.CustomerAlias

select count(*) from HistSchema.CustomerAlias
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerAlias
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerAlias
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerBase

select count(*) from HistSchema.CustomerBase
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerBase
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerBase
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerHierarchy

select count(*) from HistSchema.CustomerHierarchy
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerHierarchy
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerHierarchy
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerPortal

select count(*) from HistSchema.CustomerPortal
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerPortal
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerPortal
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------

select count(*) from dbo.CustomerRating

select count(*) from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'


------------------------------------------------------------------------------------
ASSET_TCDS
------------------------------------------------------------------------------------
select count(*) from dbo.Asset

select count(*) from HistSchema.Asset
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.Asset
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.CustomerRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'
------------------------------------------------------------------------------------

select count(*) from dbo.AssetRating

select count(*) from HistSchema.AssetRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.AssetRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.AssetRating
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

------------------------------------------------------------------------------------
IMAGINE_EQUITY_BIN 
------------------------------------------------------------------------------------

select count(*) from crdrs.AssetRating

select count(*) from HistSchema.crdStageImagineBinAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

select * from HistSchema.crdStageImagineBinAttribute
where BsnsDt='2017-07-25'
and vrsntyp = 'S'

delete from HistSchema.crdStageImagineBinAttribute
where BsnsDt='2017-07-25'

HistSchema.CustomerPortal 